//
//  O2VC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import UIKit

class O2VC: UIViewController {

    @IBOutlet weak var introLabel: UILabel!
    @IBOutlet weak var continueLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    func setUI() {
        navigationController?.setNavigationBarHidden(true, animated: false)
        setLcoalized()
    }
    func setLcoalized() {
        self.introLabel.font = FontManager.shared.font(for: .robotoSerif, size: 24.0)
        self.introLabel.text = "Enjoy Seamless Binge Watching".localized(LocalizationService.shared.language)
        self.continueLabel.text = "Continue".localized(LocalizationService.shared.language)
    }
    
    @IBAction func continueButtonAction(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "O3VC") as! O3VC
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
