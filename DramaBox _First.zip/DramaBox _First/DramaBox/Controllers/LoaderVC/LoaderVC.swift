//
//  ViewController.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import UIKit
import Lottie

class LoaderVC: UIViewController {

    @IBOutlet weak var lottieAnimationView: UIView!
    @IBOutlet weak var appTitleLabel: UILabel!
    
    var lottieFileName = "Splash lottie"
    private var animationView: LottieAnimationView?
    private var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startLottieAnimation()
        startNavigationTimer()
        fetchRemoteConfig()  // Start fetching remote config
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopNavigationTimer()
        stopLottieAnimation()
    }
    
    func setUpUI() {
        setLoca()
        setupAnimationView()
    }
    
    func setLoca() {
        self.appTitleLabel.text = "Sora Pixo".localized(LocalizationService.shared.language)
    }
    
    private func setupAnimationView() {
        animationView = LottieAnimationView(name: lottieFileName)
        animationView?.frame = lottieAnimationView.bounds
        animationView?.contentMode = .scaleAspectFit
        animationView?.loopMode = .loop
        animationView?.animationSpeed = 1.0
        
        if let animationView = animationView {
            lottieAnimationView.addSubview(animationView)
            
            animationView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                animationView.topAnchor.constraint(equalTo: lottieAnimationView.topAnchor),
                animationView.bottomAnchor.constraint(equalTo: lottieAnimationView.bottomAnchor),
                animationView.leadingAnchor.constraint(equalTo: lottieAnimationView.leadingAnchor),
                animationView.trailingAnchor.constraint(equalTo: lottieAnimationView.trailingAnchor)
            ])
        }
    }
    
    private func startLottieAnimation() {
        animationView?.play()
    }
    
    private func stopLottieAnimation() {
        animationView?.stop()
    }
    
    private func startNavigationTimer() {
        stopNavigationTimer()
        
        timer = Timer.scheduledTimer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(goToNextScreen),
            userInfo: nil,
            repeats: false
        )
    }
    
    private func stopNavigationTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    // MARK: - Remote Config (Case 1)
    private func fetchRemoteConfig() {
        // Use your actual NetworkManager - this is from your reference code
        NetworkManager.shared.fetchRemoteConfig(from: self) { result in
            switch result {
            case .success(let json):
                if let json = json as? [String: Any] {
                    let jsonDict = json
                    
                    // Parse all values exactly as in reference code
                    bannerId = (jsonDict["bannerId"] as AnyObject).stringValue ?? ""
                    nativeId = (jsonDict["nativeId"] as AnyObject).stringValue ?? ""
                    interstialId = (jsonDict["interstialId"] as AnyObject).stringValue ?? ""
                    appopenId = (jsonDict["appopenId"] as AnyObject).stringValue ?? ""
                    rewardId = (jsonDict["rewardId"] as AnyObject).stringValue ?? ""
                    
                    addButtonColor = (jsonDict["addButtonColor"] as AnyObject).stringValue ?? "#7462FF"
                    let customInterstial = (jsonDict["customInterstial"] as AnyObject).intValue ?? 0
                    
                    let afterClickValue = (jsonDict["afterClick"] as? Int) ?? Int(jsonDict["afterClick"] as? String ?? "") ?? 3
                    
                    adsCount = afterClickValue
                    adsPlus = customInterstial == 0 ? adsCount - 1 : adsCount
                    
                    if let extraFields = jsonDict["extraFields"] as? [String: Any] {

                        smallNativeBannerId = extraFields["small_native"] as? String ?? ""
                        isIAPON = extraFields["plan"] as? String ?? ""
                        IAPRequiredForTrailor = extraFields["play"] as? String ?? ""
                        prefixUrl = extraFields["appjson"] as? String ?? ""
                        NewsAPI = extraFields["story"] as? String ?? ""

                        // ✅ THIS WILL WORK
                        isShowDrama = extraFields["Open"] as? String ?? ""

                        sub = extraFields["sub"] as? Bool ?? false
                    }
                    
                    // ⭐ IMPORTANT: Save for TabbarVC
                    AppStorage.set(sub, forKey: "remoteConfig_sub_value")
                    print("✅ LoaderVC: Saved remoteConfig_sub_value = \(sub)")
                    
                    // Post notification
                    NotificationCenter.default.post(
                        name: NSNotification.Name("RemoteConfigUpdated"),
                        object: nil
                    )
                }
                
            case .failure(let error):
                print("❌ Failed to fetch config:", error.localizedDescription)
                
                // Set default value
                sub = false
                AppStorage.set(false, forKey: "remoteConfig_sub_value")
                
                // Still post notification with default
                NotificationCenter.default.post(
                    name: NSNotification.Name("RemoteConfigUpdated"),
                    object: nil
                )
            }
        }
    }
    
    @objc func goToNextScreen() {
        stopLottieAnimation()
        stopNavigationTimer()

        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate,
              let sceneWindow = sceneDelegate.window else { return }

        sceneWindow.backgroundColor = .black
        sceneWindow.subviews.forEach { $0.removeFromSuperview() }

        let initialVC: UIViewController

        if !AppStorage.contains(UserDefaultKeys.selectedLanguage) {
            initialVC = UIStoryboard(name: StoryboardName.language, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.languageVC)

        } else if !(AppStorage.get(forKey: UserDefaultKeys.hasLaunchedBefore) ?? false) {
            initialVC = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.o1VC)

            AppStorage.set(true, forKey: UserDefaultKeys.hasLaunchedBefore)

        } else {
            initialVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.tabBarVC)
        }

        sceneWindow.rootViewController = initialVC
        sceneWindow.makeKeyAndVisible()

        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.window = sceneWindow
        }
    }
}
