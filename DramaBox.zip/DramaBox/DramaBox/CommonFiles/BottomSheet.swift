//
//  BottomSheet.swift
//  DramaBox
//
//  Created by DREAMWORLD on 09/12/25.
//

import UIKit

class BottomSheetHelper {
    private static var currentContainer: UIView?
    private static var sheetContainer: UIView?
    
    static func present(view: UIView,
                       from parentVC: UIViewController,
                       initialHeightRatio: CGFloat = 0.5,
                       expandedHeightRatio: CGFloat = 0.75) {
        
        // Container - TRANSPARENT
        let container = UIView(frame: parentVC.view.bounds)
        container.backgroundColor = .clear
        currentContainer = container
        
        // Dim background - KEEP THIS for overlay effect
        let dimView = UIView(frame: container.bounds)
        dimView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        dimView.alpha = 0
        
        // Bottom sheet container - TRANSPARENT (no background color)
        let sheetContainer = UIView()
        sheetContainer.backgroundColor = .clear // TRANSPARENT
        sheetContainer.layer.cornerRadius = 20
        sheetContainer.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        sheetContainer.clipsToBounds = true
        self.sheetContainer = sheetContainer
        
        // Add your view - It will display with its original background
        view.translatesAutoresizingMaskIntoConstraints = false
        sheetContainer.addSubview(view)
        
        NSLayoutConstraint.activate([
            view.topAnchor.constraint(equalTo: sheetContainer.topAnchor),
            view.leadingAnchor.constraint(equalTo: sheetContainer.leadingAnchor),
            view.trailingAnchor.constraint(equalTo: sheetContainer.trailingAnchor),
            view.bottomAnchor.constraint(equalTo: sheetContainer.bottomAnchor)
        ])
        
        // Calculate heights
        let screenHeight = UIScreen.main.bounds.height
        let initialHeight = screenHeight * initialHeightRatio
        let expandedHeight = screenHeight * expandedHeightRatio
        
        // Initial position (off-screen)
        sheetContainer.frame = CGRect(
            x: 0,
            y: container.bounds.height,
            width: container.bounds.width,
            height: view.bounds.height > 0 ? view.bounds.height : initialHeight
        )
        
        // Add to hierarchy
        container.addSubview(dimView)
        container.addSubview(sheetContainer)
        parentVC.view.addSubview(container)
        
        // Add close button overlay (transparent but tappable)
        let closeButton = UIButton(type: .custom)
        closeButton.frame = dimView.bounds
        closeButton.backgroundColor = .clear
        closeButton.addTarget(self, action: #selector(dismiss), for: .touchUpInside)
        dimView.addSubview(closeButton)
        
        // Gestures - Add pan gesture to the view itself (not the container)
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        view.addGestureRecognizer(panGesture)
        
        // Animate in
        UIView.animate(withDuration: 0.3) {
            dimView.alpha = 1
            sheetContainer.frame.origin.y = container.bounds.height - initialHeight
        }
        
        // Store heights and view reference
        objc_setAssociatedObject(sheetContainer, "initialHeight", initialHeight, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        objc_setAssociatedObject(sheetContainer, "expandedHeight", expandedHeight, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        objc_setAssociatedObject(sheetContainer, "contentView", view, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
    }
    
    @objc private static func handlePanGesture(_ gesture: UIPanGestureRecognizer) {
        guard let contentView = gesture.view,
              let sheetView = contentView.superview,
              let superview = sheetView.superview,
              let initialHeight = objc_getAssociatedObject(sheetView, "initialHeight") as? CGFloat,
              let expandedHeight = objc_getAssociatedObject(sheetView, "expandedHeight") as? CGFloat else {
            return
        }
        
        let translation = gesture.translation(in: superview)
        let velocity = gesture.velocity(in: superview)
        
        switch gesture.state {
        case .changed:
            var newY = sheetView.frame.origin.y + translation.y
            newY = max(superview.bounds.height - expandedHeight,
                      min(newY, superview.bounds.height - initialHeight))
            sheetView.frame.origin.y = newY
            gesture.setTranslation(.zero, in: superview)
            
        case .ended:
            let shouldExpand = velocity.y < 0 ||
                              sheetView.frame.origin.y < superview.bounds.height - (initialHeight + 50)
            
            let targetY = shouldExpand ?
                superview.bounds.height - expandedHeight :
                superview.bounds.height - initialHeight
            
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut, animations: {
                sheetView.frame.origin.y = targetY
            })
            
        default:
            break
        }
    }
    
    @objc static func dismiss() {
        guard let container = currentContainer,
              let sheetView = sheetContainer else { return }
        
        UIView.animate(withDuration: 0.3, animations: {
            container.alpha = 0
            sheetView.frame.origin.y = container.bounds.height
        }) { _ in
            container.removeFromSuperview()
            currentContainer = nil
            sheetContainer = nil
        }
    }
}
extension UIView {
    func duplicate() -> UIView? {
        // Archive and unarchive to create a deep copy
        do {
            let archivedData = try NSKeyedArchiver.archivedData(withRootObject: self, requiringSecureCoding: false)
            let copy = try NSKeyedUnarchiver.unarchivedObject(ofClass: UIView.self, from: archivedData)
            return copy
        } catch {
            print("Failed to duplicate view: \(error)")
            return nil
        }
    }
}
