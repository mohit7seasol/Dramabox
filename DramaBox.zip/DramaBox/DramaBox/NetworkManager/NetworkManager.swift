//
//  NetworkManager.swift
//  DramaBox
//
//  Created by DREAMWORLD on 05/12/25.
//

import Foundation
import Alamofire
import UIKit

class NetworkManager {
    static let shared = NetworkManager()
    private init() {}
    
    private let baseProxyURL = "https://api-livevideocall.7seasol.in/proxy?url="
    
    // MARK: - Helper
    private func makeURL(for endpoint: String) -> String {
        return "\(baseProxyURL)\(endpoint.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
    }
    
    func fetchDramas(from vc: UIViewController,
                     page: Int,
                     completion: @escaping (Result<DramaResponse, Error>) -> Void) {
        
        guard ReachabilityManager.shared.isConnectedToNetwork() else {
            ReachabilityManager.shared.showNoInternetAlert(on: vc)
            return
        }
        
        let endpoint = "https://dramasstory.com/drama/new_home_screen_v2.php?currentpage=\(page)&app_ver=2.8&lc=en"
        
        // First, let's see the raw response to debug
        AF.request(makeURL(for: endpoint))
            .validate()
            .responseData { response in
                switch response.result {
                case .success(let data):
                    // Print raw response for debugging
                    if let jsonString = String(data: data, encoding: .utf8) {
                        print("API Response received")
                    }
                    
                    // Try to decode
                    do {
                        let decoder = JSONDecoder()
                        let dramaResponse = try decoder.decode(DramaResponse.self, from: data)
                        completion(.success(dramaResponse))
                    } catch let decodingError as DecodingError {
                        print("Decoding error details: \(decodingError)")
                        
                        // More detailed error information
                        switch decodingError {
                        case .keyNotFound(let key, let context):
                            print("Key '\(key.stringValue)' not found:")
                            print("codingPath: \(context.codingPath)")
                            print("debugDescription: \(context.debugDescription)")
                        case .valueNotFound(let type, let context):
                            print("Value of type '\(type)' not found:")
                            print("codingPath: \(context.codingPath)")
                        case .typeMismatch(let type, let context):
                            print("Type mismatch for type '\(type)':")
                            print("codingPath: \(context.codingPath)")
                        case .dataCorrupted(let context):
                            print("Data corrupted:")
                            print("codingPath: \(context.codingPath)")
                        @unknown default:
                            print("Unknown decoding error")
                        }
                        
                        completion(.failure(decodingError))
                    } catch {
                        completion(.failure(error))
                    }
                    
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
    func fetchEpisodes(from vc: UIViewController,
                       dramaId: String,
                       page: Int = 1,
                       completion: @escaping (Result<[EpisodeItem], Error>) -> Void) {
        
        guard ReachabilityManager.shared.isConnectedToNetwork() else {
            ReachabilityManager.shared.showNoInternetAlert(on: vc)
            return
        }
        
        let endpoint = "https://dramasstory.com/drama/drama_epi_list_v2.php?d_id=\(dramaId)&currentpage=\(page)&lc=en"
        
        AF.request(makeURL(for: endpoint))
            .validate()
            .responseData { response in  // Use responseData instead of responseDecodable
                switch response.result {
                case .success(let data):
                    do {
                        let decoder = JSONDecoder()
                        let episodeResponse = try decoder.decode(EpisodeResponse.self, from: data)
                        completion(.success(episodeResponse.data.data))
                    } catch {
                        completion(.failure(error))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
}
