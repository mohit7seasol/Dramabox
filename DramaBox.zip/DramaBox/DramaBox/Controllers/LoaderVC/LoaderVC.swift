//
//  ViewController.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import UIKit
import Lottie // Make sure to import Lottie

class LoaderVC: UIViewController {

    @IBOutlet weak var lottieAnimationView: UIView!
    @IBOutlet weak var appTitleLabel: UILabel!
    
    var lottieFileName = "Splash lottie"
    private var animationView: LottieAnimationView?
    private var timer: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startLottieAnimation()
        startNavigationTimer()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopNavigationTimer()
        stopLottieAnimation()
    }
    
    func setUpUI() {
        setLoca()
        setupAnimationView()
    }
    
    func setLoca() {
        self.appTitleLabel.text = "DramaBox".localized(LocalizationService.shared.language)
    }
    
    private func setupAnimationView() {
        // Initialize Lottie animation view
        animationView = LottieAnimationView(name: lottieFileName)
        animationView?.frame = lottieAnimationView.bounds
        animationView?.contentMode = .scaleAspectFit
        animationView?.loopMode = .loop
        animationView?.animationSpeed = 1.0
        
        if let animationView = animationView {
            lottieAnimationView.addSubview(animationView)
            
            // Add constraints to fill the parent view
            animationView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                animationView.topAnchor.constraint(equalTo: lottieAnimationView.topAnchor),
                animationView.bottomAnchor.constraint(equalTo: lottieAnimationView.bottomAnchor),
                animationView.leadingAnchor.constraint(equalTo: lottieAnimationView.leadingAnchor),
                animationView.trailingAnchor.constraint(equalTo: lottieAnimationView.trailingAnchor)
            ])
        }
    }
    
    private func startLottieAnimation() {
        animationView?.play()
    }
    
    private func stopLottieAnimation() {
        animationView?.stop()
    }
    
    private func startNavigationTimer() {
        // Stop any existing timer
        stopNavigationTimer()
        
        // Create a new timer that triggers after 5 seconds
        timer = Timer.scheduledTimer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(goToNextScreen),
            userInfo: nil,
            repeats: false
        )
    }
    
    private func stopNavigationTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    @objc func goToNextScreen() {

        stopLottieAnimation()
        stopNavigationTimer()

        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate,
              let sceneWindow = sceneDelegate.window else { return }

        // ✅ Prevent white flash
        sceneWindow.backgroundColor = .black
        sceneWindow.subviews.forEach { $0.removeFromSuperview() }

        let initialVC: UIViewController

        if !AppStorage.contains(UserDefaultKeys.selectedLanguage) {

            initialVC = UIStoryboard(name: StoryboardName.language, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.languageVC)

        } else if !(AppStorage.get(forKey: UserDefaultKeys.hasLaunchedBefore) ?? false) {

            initialVC = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.o1VC)

            AppStorage.set(true, forKey: UserDefaultKeys.hasLaunchedBefore)

        } else {

            initialVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.tabBarVC)
        }

        // ✅ IMPORTANT: No NavigationController
        sceneWindow.rootViewController = initialVC
        sceneWindow.makeKeyAndVisible()

        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.window = sceneWindow
        }
    }

}
