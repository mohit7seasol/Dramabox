//
//  HomeVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import Foundation
import Alamofire
import UIKit
import SVProgressHUD
import Lottie

class HomeVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var appNameLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var lottieAnimationLoadingView: UIView!
    
    // Properties for pagination
    private var currentPage = 1
    private var isLoading = false
    private var hasMoreData = true
    private var allDramas: [DramaItem] = []
    
    // Data for sections
    private var popularDramas: [DramaItem] = []
    private var newDramas: [DramaItem] = []
    private var hotPicks: [DramaItem] = []
    private var autoScrollTimer: Timer?
    private var splashLoader: LottieAnimationView?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        setTable()
        fetchDramas(page: 1)
    }
    // https://www.figma.com/design/sHEB4XZNOoVKWpctOyNqel/Drama-Box?node-id=0-1&p=f&t=GMy9sWtNjF8xQeQf-0
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        startAutoScroll()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopAutoScroll()
    }
    
    deinit {
        stopAutoScroll()
    }
    
    func setUpUI() {
        SearchBarStyle.apply(to: searchBar)
        
        // Set welcome labels
        welcomeLabel.text = "Welcome to".localized(LocalizationService.shared.language)
        self.appNameLabel.text = "DramaBox".localized(LocalizationService.shared.language)
        self.appNameLabel.font = FontManager.shared.font(for: .robotoSerif, size: 20.0)
        
        welcomeLabel.font = FontManager.shared.font(for: .roboto, size: 14.0)
        appNameLabel.font = FontManager.shared.font(for: .roboto, size: 20.0)
        
        // Set linear gradient background like in uploaded image
        setGradientBackground()
    }
    func showLottieLoader() {
        // already showing → ignore
        if splashLoader != nil { return }
        
        splashLoader = LottieAnimationView(name: "Splash lottie")
        guard let loader = splashLoader else { return }

        loader.frame = view.bounds
        loader.contentMode = .scaleAspectFit
        loader.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        loader.loopMode = .loop

        view.addSubview(loader)
        view.bringSubviewToFront(loader)

        loader.play()
    }
    func hideLottieLoader() {
        guard let loader = splashLoader else { return }
        loader.stop()
        loader.removeFromSuperview()
        splashLoader = nil
    }
    
    private func setGradientBackground() {
        let gradientLayer = CAGradientLayer()
        
        gradientLayer.colors = [
            UIColor(hex: "#111111")!.cgColor,   // Top
            UIColor(hex: "#171717")!.cgColor,   // Middle
            UIColor(hex: "#0B0B0B")!.cgColor    // Bottom
        ]
        
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradientLayer.frame = view.bounds

        // ✅ Remove only existing gradients (safe)
        view.layer.sublayers?.removeAll(where: { $0 is CAGradientLayer })

        view.layer.insertSublayer(gradientLayer, at: 0)

        tableView.backgroundColor = .clear
    }
    
    func setTable() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        // Register cells
        self.tableView.register(UINib(nibName: "CarouselTopCell", bundle: nil), forCellReuseIdentifier: "CarouselTopCell")
        self.tableView.register(UINib(nibName: "TitleHeaderCell", bundle: nil), forCellReuseIdentifier: "TitleHeaderCell")
        
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = .clear
        
        let footer = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 20))
        footer.backgroundColor = .clear
        tableView.tableFooterView = footer
    }
    
    private func startAutoScroll() {
        stopAutoScroll()
        autoScrollTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            // Scroll the first section's collection view
            if let carouselCell = self.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? CarouselTopCell {
                carouselCell.scrollToNextItem()
            }
        }
    }
    
    private func stopAutoScroll() {
        autoScrollTimer?.invalidate()
        autoScrollTimer = nil
    }
    func navigateToAllHotAndNew(type: DramaTypes, allDramas: [DramaItem]) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "AllHotePicksAndNewDramaVC") as? AllHotePicksAndNewDramaVC {
            vc.dramaType = type
            vc.dramaList = allDramas
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    func navigateToViewAllEpisodes(for dramaId: String, dramaName: String?, allEpisodes: [EpisodeItem] = []) {
        // Navigate to ViewAllEpisodsStoriesVC
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let viewAllEpisodesVC = storyboard.instantiateViewController(withIdentifier: "ViewAllEpisodsStoriesVC") as? ViewAllEpisodsStoriesVC {
            viewAllEpisodesVC.dramaId = dramaId
            viewAllEpisodesVC.dramaName = dramaName
            viewAllEpisodesVC.storiesPlayingViewType = .isOpenAllStoriesEpisods
            viewAllEpisodesVC.allEpisodes = allEpisodes
            viewAllEpisodesVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(viewAllEpisodesVC, animated: true)
        }
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension HomeVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0: // Carousel section
            return 210
        case 1: // New Dramas section
            return 240
        case 2: // Hot Picks section - Dynamic height
            let itemHeight: CGFloat = 120
            let interItemSpacing: CGFloat = 15
            let topBottomPadding: CGFloat = 10   // 5 top + 5 bottom ✅
            let titleHeight: CGFloat = 40        // Label height

            let rows = CGFloat(5) // Calculate only 5 row heights
            let totalHeight =
                (rows * itemHeight) +
                (max(0, rows - 1) * interItemSpacing) +
                titleHeight +
                topBottomPadding

            return totalHeight - 20
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0: // Carousel section
            let cell = tableView.dequeueReusableCell(withIdentifier: "CarouselTopCell", for: indexPath) as! CarouselTopCell
            cell.configure(with: Array(popularDramas.prefix(10)))
            cell.selectionStyle = .none
            cell.contentView.backgroundColor = .clear
            cell.backgroundColor = .clear
            // open ViewAllEpisodsStoriesVC and pass drama id
            cell.didSelectDrama = { [weak self] drama in
                self?.navigateToViewAllEpisodes(
                    for: drama.id ?? "",
                    dramaName: drama.dramaName,
                    allEpisodes: []
                )
            }
            return cell
            
        case 1: // New Dramas section
            let cell = tableView.dequeueReusableCell(withIdentifier: "TitleHeaderCell", for: indexPath) as! TitleHeaderCell
            cell.selectionStyle = .none
            cell.contentView.backgroundColor = .clear
            cell.backgroundColor = .clear
            
            cell.configure(type: .NewDramas, title: "New Dramas".localized(LocalizationService.shared.language))
            cell.viewAllButton.setTitle("View All".localized(LocalizationService.shared.language), for: .normal)
            cell.loadNewDramas( Array(newDramas.prefix(10)))
            cell.setCollectionViewLayout(itemWidth: 136, itemHeight: 200, scrollDirection: .horizontal)
            cell.viewAllButton.isHidden = false
            
            cell.viewAllButton.setOnClickListener {
                self.navigateToAllHotAndNew(type: .new, allDramas: self.newDramas)
            }
            // open ViewAllEpisodsStoriesVC and pass drama id
            cell.didSelectDrama = { [weak self] drama in
                self?.navigateToViewAllEpisodes(
                    for: drama.id ?? "",
                    dramaName: drama.dramaName,
                    allEpisodes: []
                )
            }
            return cell
            
        case 2: // Hot Picks section
            let cell = tableView.dequeueReusableCell(withIdentifier: "TitleHeaderCell", for: indexPath) as! TitleHeaderCell
            cell.selectionStyle = .none
            cell.contentView.backgroundColor = .clear
            cell.backgroundColor = .clear
            
            cell.configure(type: .HotPicks, title: "Hot Picks🔥".localized(LocalizationService.shared.language))
            cell.viewAllButton.setTitle("View All".localized(LocalizationService.shared.language), for: .normal)
            cell.loadHotPicks(Array(hotPicks.prefix(5)))
            // For Hot Picks, use full width with 1 item per row
            let itemWidth = tableView.frame.width - 20 // 10px padding on each side
            cell.setCollectionViewLayout(itemWidth: itemWidth, itemHeight: 120, scrollDirection: .vertical, isScrollEnabled: false)
            cell.viewAllButton.isHidden = false
            
            cell.viewAllButton.setOnClickListener {
                self.navigateToAllHotAndNew(type: .hot, allDramas: self.hotPicks)
            }
            // open ViewAllEpisodsStoriesVC and pass drama id
            cell.didSelectDrama = { [weak self] drama in
                self?.navigateToViewAllEpisodes(
                    for: drama.id ?? "",
                    dramaName: drama.dramaName,
                    allEpisodes: []
                )
            }
            return cell
            
        default:
            return UITableViewCell()
        }
    }
}

// MARK: - Api's calling
extension HomeVC {
    func fetchDramas(page: Int, isLoadMore: Bool = false) {
        guard !isLoading, (isLoadMore ? hasMoreData : true) else { return }

        isLoading = true
        
        if !isLoadMore {
            showLottieLoader()
        }

        NetworkManager.shared.fetchDramas(from: self, page: page) { [weak self] result in
            guard let self = self else { return }

            self.isLoading = false
            self.tableView.refreshControl?.endRefreshing()

            if !isLoadMore {
                self.hideLottieLoader()
            }

            switch result {
            case .success(let response):

                if !isLoadMore {
                    self.popularDramas.removeAll()
                    self.newDramas.removeAll()
                    self.hotPicks.removeAll()
                }
                
                // Same processing code you already have ↓
                for section in response.data.data {
                    let validItems = section.list.filter {
                        ($0.dramaName?.isEmpty == false) &&
                        ($0.imageUrl?.isEmpty == false)
                    }

                    if section.heading == "Popular Dramas" {
                        self.popularDramas = validItems
                    } else if section.heading == "Coming Soon...." {
                        self.newDramas = validItems
                    } else {
                        self.hotPicks.append(contentsOf: validItems)
                    }
                }
                
                self.hasMoreData = !response.data.data.isEmpty
                if self.hasMoreData { self.currentPage = page }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    self.startAutoScroll()

                    if self.popularDramas.isEmpty &&
                       self.newDramas.isEmpty &&
                       self.hotPicks.isEmpty {
                        self.showEmptyState()
                    } else {
                        self.hideEmptyState()
                    }
                }

            case .failure(let error):
                print("Error fetching dramas: \(error.localizedDescription)")
                
                DispatchQueue.main.async {
                    self.hideLottieLoader()
                    if self.allDramas.isEmpty { self.showEmptyState() }
                }
            }
        }
    }
    
    private func showEmptyState() {
        hideEmptyState()
        
        let emptyView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: tableView.bounds.height))
        emptyView.backgroundColor = .clear
        
        let label = UILabel()
        label.text = "No dramas found"
        label.textAlignment = .center
        label.textColor = .lightGray
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        emptyView.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: emptyView.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: emptyView.centerYAnchor)
        ])
        
        emptyView.tag = 999
        tableView.addSubview(emptyView)
    }
    
    private func hideEmptyState() {
        if let emptyView = tableView.viewWithTag(999) {
            emptyView.removeFromSuperview()
        }
    }
}
