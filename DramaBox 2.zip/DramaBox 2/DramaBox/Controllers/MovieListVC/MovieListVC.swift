//
//  MovieListVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 22/01/26.
//

import UIKit

class MovieListVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
