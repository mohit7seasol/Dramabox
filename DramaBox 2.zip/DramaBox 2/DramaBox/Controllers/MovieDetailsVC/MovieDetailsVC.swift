//
//  MovieDetailsVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 22/01/26.
//

import UIKit
import Cosmos
import SVProgressHUD
import SDWebImage

class MovieDetailsVC: UIViewController {

    @IBOutlet weak var movieThumbImageView: UIImageView!
    @IBOutlet weak var movieNameLabel: UILabel!
    @IBOutlet weak var genereNameLabel: UILabel!
    @IBOutlet weak var overViewLabel: UILabel!
    @IBOutlet weak var readMoreButton: UIButton!
    @IBOutlet weak var reedMoreLabel: UILabel!
    @IBOutlet weak var readMoreImageView: UIImageView!
    @IBOutlet weak var posterLabel: UILabel!
    @IBOutlet weak var posterViewAllButton: UIButton!
    @IBOutlet weak var posterCollection: UICollectionView!
    @IBOutlet weak var videoTitleLabel: UILabel!
    @IBOutlet weak var videoviewAllButton: UIButton!
    @IBOutlet weak var videoCollection: UICollectionView!
    @IBOutlet weak var rateView: CosmosView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    var movieDetails: MovieDetails?
    private var isExpanded = false
    var movieId: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        setupReadMore()
        if let movieId = movieId {
            fetchMovieDetails(movieId: movieId)
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // 1. Ensure scroll view content starts from top
        scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func setUI() {
        // 1. Remove scroll view top space
        if #available(iOS 11.0, *) {
            scrollView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        
        setColelcetionView()
        setupLabels()
        
        // Set default image for thumb
        movieThumbImageView.image = UIImage(named: "hoteDefault")
        rateView.settings.updateOnTouch = false 
    }
    
    func setupLabels() {
        // Localize labels
        posterLabel.text = "Posters".localized(LocalizationService.shared.language)
        videoTitleLabel.text = "Videos".localized(LocalizationService.shared.language)
        posterViewAllButton.setTitle("View All".localized(LocalizationService.shared.language), for: .normal)
        videoviewAllButton.setTitle("View All".localized(LocalizationService.shared.language), for: .normal)
        
        // Set read more initial state
        reedMoreLabel.text = "Read More".localized(LocalizationService.shared.language)
        readMoreImageView.image = UIImage(named: "down_arrow")
        
        // Set initial overview label properties
        overViewLabel.numberOfLines = 4
        overViewLabel.lineBreakMode = .byTruncatingTail
    }
    
    func setupReadMore() {
        // Set initial state
        updateReadMoreUI()
    }
    
    private func updateReadMoreUI() {
        overViewLabel.numberOfLines = isExpanded ? 0 : 4
        
        if isExpanded {
            reedMoreLabel.text = "Read Less".localized(LocalizationService.shared.language)
            readMoreImageView.image = UIImage(named: "up_arrow")
        } else {
            reedMoreLabel.text = "Read More".localized(LocalizationService.shared.language)
            readMoreImageView.image = UIImage(named: "down_arrow")
        }
    }
    
    func setColelcetionView() {
        // Setup Poster Collection
        let posterLayout = UICollectionViewFlowLayout()
        posterLayout.scrollDirection = .horizontal
        posterLayout.minimumLineSpacing = 10
        posterLayout.minimumInteritemSpacing = 10
        let posterCellWidth = posterCollection.frame.width / 2.4
        posterLayout.itemSize = CGSize(width: posterCellWidth, height: 170)
        posterLayout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        posterCollection.collectionViewLayout = posterLayout
        posterCollection.delegate = self
        posterCollection.dataSource = self
        posterCollection.showsHorizontalScrollIndicator = false
        posterCollection.backgroundColor = .clear
        posterCollection.register(UINib(nibName: "MovieYoutubeVideoCell", bundle: nil), forCellWithReuseIdentifier: "MovieYoutubeVideoCell")
        
        // Setup Video Collection
        let videoLayout = UICollectionViewFlowLayout()
        videoLayout.scrollDirection = .horizontal
        videoLayout.minimumLineSpacing = 10
        videoLayout.minimumInteritemSpacing = 10
        videoLayout.itemSize = CGSize(width: 230, height: 150)
        videoLayout.sectionInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        videoCollection.collectionViewLayout = videoLayout
        videoCollection.delegate = self
        videoCollection.dataSource = self
        videoCollection.showsHorizontalScrollIndicator = false
        videoCollection.backgroundColor = .clear
        videoCollection.register(UINib(nibName: "MovieYoutubeVideoCell", bundle: nil), forCellWithReuseIdentifier: "MovieYoutubeVideoCell")
    }
    
    private func updateUI() {
        guard let movieDetails = movieDetails else { return }
        
        // Set movie thumb image with default fallback
        if let backdropPath = movieDetails.backdropPath,
           let url = URL(string: "https://image.tmdb.org/t/p/w500\(backdropPath)") {
            movieThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "hoteDefault"))
        }
        
        // Set movie name
        movieNameLabel.text = movieDetails.title
        
        // Set genres
        let genres = movieDetails.genres.prefix(3).map { $0.name }.joined(separator: ", ")
        genereNameLabel.text = genres
        
        // Set overview
        overViewLabel.text = movieDetails.overview
        
        // Set rating
        rateView.rating = movieDetails.voteAverage / 2 // Convert 10-point scale to 5-star scale
        
        // Reload collections
        posterCollection.reloadData()
        videoCollection.reloadData()
    }
    
    @IBAction func readMoreButton(_ sender: UIButton) {
        isExpanded.toggle()
        updateReadMoreUI()
    }
    
    @IBAction func backButtonTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func playButtonAction(_ sender: UIButton) {
        if let trailer = self.movieDetails?.videos?.results.first(where: {
            $0.type == "Trailer" && $0.site == "YouTube"
        }) {
            self.openYouTube(videoKey: trailer.key)
        } else {
            print("⚠️ No YouTube trailer found.")
        }
    }
    
    @IBAction func viewAllPosterButtonAction(_ sender: UIButton) {
        self.openPosterDetailsVC()
    }
    
}

extension MovieDetailsVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let movieDetails = movieDetails else { return 0 }
        
        if collectionView == posterCollection {
            return movieDetails.images?.posters.count ?? 0
        } else if collectionView == videoCollection {
            return movieDetails.videos?.results.count ?? 0
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieYoutubeVideoCell", for: indexPath) as! MovieYoutubeVideoCell
        
        guard let movieDetails = movieDetails else { return cell }
        
        if collectionView == posterCollection {
            // Configure for posters
            if let posters = movieDetails.images?.posters,
               indexPath.item < posters.count {
                let poster = posters[indexPath.item]
                let imageUrl = "https://image.tmdb.org/t/p/w500\(poster.filePath)"
                if let url = URL(string: imageUrl) {
                    cell.videoThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "hoteDefault"))
                }
            }
            cell.playButton.isHidden = true
            
            cell.setOnClickListener {
                self.openPosterDetailsVC(startingIndex: indexPath.item)
            }
            
        } else if collectionView == videoCollection {
            // Configure for videos
            if let videos = movieDetails.videos?.results,
               indexPath.item < videos.count {
                let video = videos[indexPath.item]
                let youtubeThumbUrl = "https://img.youtube.com/vi/\(video.key)/0.jpg"
                if let url = URL(string: youtubeThumbUrl) {
                    cell.videoThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "hoteDefault"))
                }
            }
            cell.playButton.isHidden = false
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == videoCollection,
           let videos = movieDetails?.videos?.results,
           indexPath.item < videos.count {
            let video = videos[indexPath.item]
            self.openYouTube(videoKey: video.key)
        }
    }
    
    // ✅ Linear effect like FSPagerView for video collection
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView == videoCollection {
            let centerX = scrollView.contentOffset.x + (videoCollection.bounds.width / 2)
            
            for cell in videoCollection.visibleCells {
                let basePosition = cell.center.x
                let distance = abs(centerX - basePosition)
                let normalized = distance / (videoCollection.bounds.width / 2)
                let scale = max(0.85, 1 - normalized * 0.15)
                
                cell.transform = CGAffineTransform(scaleX: scale, y: scale)
                cell.alpha = scale
            }
        }
    }
    func openYouTube(videoKey: String) {
        let appURL = URL(string: "youtube://\(videoKey)")!
        let webURL = URL(string: "https://www.youtube.com/watch?v=\(videoKey)")!
        
        if UIApplication.shared.canOpenURL(appURL) {
            UIApplication.shared.open(appURL, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.open(webURL, options: [:], completionHandler: nil)
        }
    }
    private func openPosterDetailsVC() {
        guard let posters = movieDetails?.images?.posters, !posters.isEmpty else { return }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let posterListVC = storyboard.instantiateViewController(withIdentifier: "PosterListVC") as? PosterListVC {
            posterListVC.posters = posters
            posterListVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(posterListVC, animated: true)
        }
    }
    private func openPosterDetailsVC(startingIndex: Int) {
        guard let posters = movieDetails?.images?.posters, !posters.isEmpty else { return }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let posterDetailsVC = storyboard.instantiateViewController(withIdentifier: "PosterDetailsVC") as? PosterDetailsVC {
            posterDetailsVC.posters = posters
            posterDetailsVC.currentIndex = startingIndex
            posterDetailsVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(posterDetailsVC, animated: true)
        }
    }
}

extension MovieDetailsVC {
    func fetchMovieDetails(movieId: Int) {
        self.movieId = movieId
        SVProgressHUD.show()
        NetworkManager.shared.fetchMovieDetails(movieId: movieId) { [weak self] result in
            SVProgressHUD.dismiss()
            switch result {
            case .success(let movieDetails):
                self?.movieDetails = movieDetails
                DispatchQueue.main.async {
                    self?.updateUI()
                }
                print("Fetched Movie: \(movieDetails.title)")
            case .failure(let error):
                print("Error fetching movie details: \(error.localizedDescription)")
            }
        }
    }
}
