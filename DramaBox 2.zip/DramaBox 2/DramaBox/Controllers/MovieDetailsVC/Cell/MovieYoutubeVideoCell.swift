//
//  MovieYoutubeVideoCell.swift
//  DramaBox
//
//  Created by DREAMWORLD on 22/01/26.
//

import UIKit

class MovieYoutubeVideoCell: UICollectionViewCell {
    @IBOutlet weak var videoThumbImageView: UIImageView!
    @IBOutlet weak var playButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
