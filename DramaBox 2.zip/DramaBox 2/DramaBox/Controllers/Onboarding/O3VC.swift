//
//  O3VC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import UIKit

class O3VC: UIViewController {

    @IBOutlet weak var introLabel: UILabel!
    @IBOutlet weak var continueLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    func setUI() {
        navigationController?.setNavigationBarHidden(true, animated: false)
        setLcoalized()
    }
    func setLcoalized() {
        self.introLabel.font = FontManager.shared.font(for: .robotoSerif, size: 24.0)
        self.introLabel.text = "Immerse In Dramas Enjoy HD Quality".localized(LocalizationService.shared.language)
        self.continueLabel.text = "Continue".localized(LocalizationService.shared.language)
    }
    
    @IBAction func continueButtonAction(_ sender: UIButton) {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate,
              let window = sceneDelegate.window else { return }
        
        let tabBarVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
            .instantiateViewController(withIdentifier: Controllers.tabBarVC)
        
        window.rootViewController = tabBarVC
        window.makeKeyAndVisible()
    }
}
