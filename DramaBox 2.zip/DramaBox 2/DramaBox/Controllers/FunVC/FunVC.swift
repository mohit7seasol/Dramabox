//
//  FunVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 16/01/26.
//

import UIKit

class FunVC: UIViewController {
    
    @IBOutlet weak var movieTitleLbl: UILabel!
    @IBOutlet weak var movieSubTitleLbl: UILabel!
    @IBOutlet weak var quizeTitleLbl: UILabel!
    @IBOutlet weak var quizeSubTitleLbl: UILabel!
    @IBOutlet weak var spinTitleLbl: UILabel!
    @IBOutlet weak var ringtoneLbl: UILabel!
    @IBOutlet weak var spinSubTitleLbl: UILabel!
    @IBOutlet weak var wallpaperLbl: UILabel!
    @IBOutlet weak var viewAllButton: UIButton!
    @IBOutlet weak var wallpapersCollectionView: UICollectionView!
    
    var wallpaperURLs: [String] = []
    var displayWallpaperURLs: [String] = [] // Will store only first 10 items
    
    var ringtoneCategories: RingtoneResponse = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        fetchRingtones()
        fetchWallpapers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    func setUI() {
        setLoca()
        setCollectionView()
    }
    
    func setLoca() {
        movieTitleLbl.text = "Guess the Movie".localized(LocalizationService.shared.language)
        movieSubTitleLbl.text = "Solve clues and reveal the movie title.".localized(LocalizationService.shared.language)
        quizeTitleLbl.text = "Movie Quiz".localized(LocalizationService.shared.language)
        quizeSubTitleLbl.text = "Answer fun questions about movies and shows.".localized(LocalizationService.shared.language)
        spinTitleLbl.text = "Spin the Wheel".localized(LocalizationService.shared.language)
        spinSubTitleLbl.text = "Let the wheel choose what to watch.".localized(LocalizationService.shared.language)
        ringtoneLbl.text = "Ringtones".localized(LocalizationService.shared.language)
        wallpaperLbl.text = "Wallpaper".localized(LocalizationService.shared.language)
        viewAllButton.setTitle("View All".localized(LocalizationService.shared.language), for: .normal)
    }
    
    func setCollectionView() {
        wallpapersCollectionView.dataSource = self
        wallpapersCollectionView.delegate = self
        
        // Register cell with identifier
        let nib = UINib(nibName: "WallpaperCell", bundle: nil)
        wallpapersCollectionView.register(nib, forCellWithReuseIdentifier: "WallpaperCell")
        
        // Set collection view layout
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 140, height: 110)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        wallpapersCollectionView.collectionViewLayout = layout
        
        wallpapersCollectionView.showsHorizontalScrollIndicator = false
    }
}

// MARK: - UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
extension FunVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // Display only first 10 items or total count if less than 10
        return min(displayWallpaperURLs.count, 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let wallpaperCell = collectionView.dequeueReusableCell(withReuseIdentifier: "WallpaperCell", for: indexPath) as? WallpaperCell else {
            return UICollectionViewCell()
        }
        
        if indexPath.item < displayWallpaperURLs.count {
            wallpaperCell.configure(with: displayWallpaperURLs[indexPath.item])
        }
        
        return wallpaperCell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Set cell size to width: 150, height: 110
        return CGSize(width: 150, height: 110)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Handle wallpaper selection if needed
        if indexPath.item < displayWallpaperURLs.count {
            let selectedWallpaperURL = displayWallpaperURLs[indexPath.item]
            print("Selected wallpaper: \(selectedWallpaperURL)")
        }
    }
}

// MARK: - Api's calling
extension FunVC {
    // MARK: - Fetch Wallpapers
    func fetchWallpapers() {
        NetworkManager.shared.fetchWallpapers(from: self) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let wallpapers):
                    self?.handleWallpapersResponse(wallpapers)
                case .failure(let error):
                    self?.handleError(error)
                }
            }
        }
    }
    
    private func handleWallpapersResponse(_ wallpapers: [String]) {
        print("Fetched \(wallpapers.count) wallpapers")
        
        // Store all wallpapers
        self.wallpaperURLs = wallpapers
        
        // Take only first 10 items for display
        self.displayWallpaperURLs = Array(wallpapers.prefix(10))
        
        // Reload collection view
        self.wallpapersCollectionView.reloadData()
        
        // Preload images for better performance
        preloadWallpaperImages()
    }
    
    private func handleError(_ error: Error) {
        print("Error: \(error.localizedDescription)")
        
        // If there's an error, you might want to show some placeholder data
        // For now, just reload with empty data
        self.displayWallpaperURLs = []
        self.wallpapersCollectionView.reloadData()
        
        // Show alert to user
        let alert = UIAlertController(title: "Error",
                                    message: error.localizedDescription,
                                    preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
    }
    
    // MARK: - Preload Wallpaper Images (Optional)
    private func preloadWallpaperImages() {
        // Preload first 5 wallpapers for better user experience
        let urlsToPreload = Array(displayWallpaperURLs.prefix(5))
        
        for urlString in urlsToPreload {
            NetworkManager.shared.downloadImage(from: urlString) { result in
                switch result {
                case .success(let image):
                    // Cache the image or store for later use
                    print("Preloaded image: \(urlString)")
                case .failure(let error):
                    print("Failed to preload image: \(error.localizedDescription)")
                }
            }
        }
    }
    // MARK: - Fetch Ringtones
    func fetchRingtones() {
        NetworkManager.shared.fetchRingtones(from: self) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let ringtoneCategories):
                    self?.handleRingtonesResponse(ringtoneCategories)
                case .failure(let error):
                    self?.handleError(error)
                }
            }
        }
    }
    // MARK: - Handle Ringtones Response
    private func handleRingtonesResponse(_ categories: RingtoneResponse) {
        // Process and display ringtones
        print("Fetched \(categories.count) ringtone categories")
        
        // Example: Store in local array or update UI
        self.ringtoneCategories = categories
        
        // Print categories and counts for debugging
        for category in categories {
            print("Category: \(category.category) - \(category.ringtones.count) ringtones")
        }
    }
}

// MARK: - Button Actions
extension FunVC {
    @IBAction func movieButtonTap(_ sender: UIButton) {
        // Handle movie button tap
    }
    
    @IBAction func quizeButtonTap(_ sender: UIButton) {
        // Handle quiz button tap
    }
    
    @IBAction func spinButtonTap(_ sender: UIButton) {
        // Handle spin button tap
    }
    
    @IBAction func ringtonsButtonTap(_ sender: UIButton) {
        // Handle ringtones button tap
    }
    
    @IBAction func viewAllButtonTap(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: StoryboardName.main, bundle: nil)
        if let allWallpapersController = storyboard.instantiateViewController(withIdentifier: "WallPapersVC") as? WallPapersVC {
            allWallpapersController.contentItems = self.wallpaperURLs
            allWallpapersController.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(allWallpapersController, animated: true)
        }
    }
}
