//
//  RingtoneCategoriesVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 20/01/26.
//

import UIKit

class RingtoneCategoriesVC: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var titleLabel: UILabel!
    
    var ringtoneCategories: RingtoneResponse = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func setUpUI() {
        self.titleLabel.text = "Music".localized(LocalizationService.shared.language)
        if ringtoneCategories.isEmpty {
            self.collectionView.isHidden = true
            showEmptyState()
        } else {
            self.collectionView.isHidden = false
            hideEmptyState()
        }
        setUpCollectionView()
    }
    
    private func showEmptyState() {
        let emptyLabel = UILabel(frame: CGRect(x: 0, y: 0, width: collectionView.bounds.width, height: collectionView.bounds.height))
        emptyLabel.text = "No categories available"
        emptyLabel.textColor = .white.withAlphaComponent(0.7)
        emptyLabel.textAlignment = .center
        emptyLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        emptyLabel.alpha = 0
        
        collectionView.backgroundView = emptyLabel
        
        UIView.animate(withDuration: 0.3) {
            emptyLabel.alpha = 1
        }
    }
    
    private func hideEmptyState() {
        collectionView.backgroundView = nil
    }
    
    func setUpCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.showsVerticalScrollIndicator = false
        collectionView.backgroundColor = .clear
        collectionView.bounces = true
        collectionView.contentInsetAdjustmentBehavior = .never
        
        // Set up layout with 0 spacing
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 0  // Zero spacing between rows
        layout.minimumInteritemSpacing = 0  // Zero spacing between columns
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)  // Zero inset on all sides
        
        // Single column - full width items
        let screenWidth = UIScreen.main.bounds.width
        layout.itemSize = CGSize(width: screenWidth, height: 60)  // Consistent height for all cells
        
        collectionView.collectionViewLayout = layout
        
        // Register cell
        collectionView.register(["RingtoneCateCell"])
        collectionView.reloadData()
    }
    
    @IBAction func backButtonTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
extension RingtoneCategoriesVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ringtoneCategories.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RingtoneCateCell", for: indexPath) as? RingtoneCateCell ?? RingtoneCateCell()
        
        let category = ringtoneCategories[indexPath.item]
        cell.configure(with: category)
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let screenWidth = UIScreen.main.bounds.width
        return CGSize(width: screenWidth, height: 60)  // Consistent height for all cells
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Add selection animation
        if let cell = collectionView.cellForItem(at: indexPath) as? RingtoneCateCell {
            cell.animateSelection()
        }
        
        // Delay navigation to show animation
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            let category = self.ringtoneCategories[indexPath.item]
            self.navigateToRingtonesList(for: category)
        }
    }
    private func navigateToRingtonesList(for category: RingtoneCategory) {
        print("Selected category: \(category.category)")
        let storyboard = UIStoryboard(name: StoryboardName.main, bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "RingtoneListVC") as? RingtoneListVC {
            vc.selectedCategory = category
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
