//
//  PosterListVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 22/01/26.
//

import UIKit
import SDWebImage

class PosterListVC: UIViewController {
    
    @IBOutlet weak var posterCollection: UICollectionView!
    
    var posters: [ImageData] = []
    var selectedIndex = 0
    var isPoster: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        setupNavigation()
    }
    
    private func setupNavigation() {
        // Set navigation title
        navigationItem.title = "Posters"
        
        // Add back button
        let backButton = UIBarButtonItem(image: UIImage(named: "back"), style: .plain, target: self, action: #selector(backButtonTapped))
        navigationItem.leftBarButtonItem = backButton
    }
    
    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }
    
    private func setupCollectionView() {
        // Create custom layout for 2x2 grid
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        
        // Calculate cell size for 2x2 grid
        let spacing: CGFloat = 10
        let totalHorizontalSpacing = spacing * 3 // left + right + between columns
        let itemWidth = (posterCollection.frame.width - totalHorizontalSpacing) / 2
        
        // Maintain 2:3 aspect ratio for posters (standard movie poster ratio)
        let itemHeight = itemWidth * 1.5
        
        layout.itemSize = CGSize(width: itemWidth, height: itemHeight)
        layout.minimumLineSpacing = spacing
        layout.minimumInteritemSpacing = spacing
        layout.sectionInset = UIEdgeInsets(top: spacing, left: spacing, bottom: spacing, right: spacing)
        
        posterCollection.collectionViewLayout = layout
        posterCollection.delegate = self
        posterCollection.dataSource = self
        posterCollection.backgroundColor = .clear
        
        // Register cell
        posterCollection.register(UINib(nibName: "MovieYoutubeVideoCell", bundle: nil), forCellWithReuseIdentifier: "MovieYoutubeVideoCell")
    }
    
    func updatePosters(_ posters: [ImageData]) {
        self.posters = posters
        posterCollection.reloadData()
        updateNavigationTitle()
    }
    
    private func updateNavigationTitle() {
        navigationItem.title = "Posters (\(posters.count))"
    }
    
    @IBAction func backButtonTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension PosterListVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return posters.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieYoutubeVideoCell", for: indexPath) as! MovieYoutubeVideoCell
        
        let poster = posters[indexPath.item]
        
        // Load poster image
        let imageUrl = "https://image.tmdb.org/t/p/w500\(poster.filePath)"
        if let url = URL(string: imageUrl) {
            cell.videoThumbImageView.sd_setImage(
                with: url,
                placeholderImage: UIImage(named: "hoteDefault"),
                options: [.retryFailed, .continueInBackground]
            )
        }
        
        // Hide play button for posters
        cell.playButton.isHidden = true
        
        // Style the cell
        cell.layer.cornerRadius = 16
        cell.layer.masksToBounds = true
        cell.layer.borderWidth = 1
        cell.layer.borderColor = UIColor.darkGray.cgColor
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        openPosterDetailsVC()
    }
    
    private func openPosterDetailsVC() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let posterDetailsVC = storyboard.instantiateViewController(withIdentifier: "PosterDetailsVC") as? PosterDetailsVC {
            posterDetailsVC.posters = posters
            posterDetailsVC.currentIndex = selectedIndex
            posterDetailsVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(posterDetailsVC, animated: true)
        }
    }
    
    // Optional: Adjust cell size for different orientations
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Maintain 2x2 grid layout
        let spacing: CGFloat = 10
        let totalHorizontalSpacing = spacing * 3 // left + right + between columns
        
        // Calculate width for 2 columns
        let itemWidth = (collectionView.frame.width - totalHorizontalSpacing) / 2
        
        // Maintain 2:3 aspect ratio (standard poster ratio)
        let itemHeight = itemWidth * 1.5
        
        return CGSize(width: itemWidth, height: itemHeight)
    }
}
