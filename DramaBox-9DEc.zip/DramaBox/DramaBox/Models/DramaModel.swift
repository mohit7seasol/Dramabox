//
//  DramaModel.swift
//  DramaBox
//
//  Created by DREAMWORLD on 05/12/25.
//

import Foundation

struct DramaResponse: Codable {
    let httpResponseCode: Int
    let httpResponseMessage: String
    let data: DramaData
    
    enum CodingKeys: String, CodingKey {
        case httpResponseCode = "http_response_code"
        case httpResponseMessage = "http_response_message"
        case data
    }
}

struct DramaData: Codable {
    let errorCode: Int
    let errorMessage: String
    let data: [DramaSection]
    
    enum CodingKeys: String, CodingKey {
        case errorCode = "ErrorCode"
        case errorMessage = "ErrorMessage"
        case data = "Data"
    }
}

struct DramaSection: Codable {
    let listType: String
    let heading: String
    let type: String
    let eventName: String
    let more: Int
    let moreLink: String
    let moreParameters: String
    let style: String
    let moreParameterValue: String
    let list: [DramaItem]
    
    enum CodingKeys: String, CodingKey {
        case listType = "list_type"
        case heading
        case type
        case eventName = "event_name"
        case more
        case moreLink = "more_link"
        case moreParameters = "more_parameters"
        case style
        case moreParameterValue = "more_parameter_value"
        case list
    }
}

struct DramaItem: Codable {
    let id: String?
    let dramaName: String?
    let dKeywords: String?
    let totalEpisodes: String?
    let dDesc: String?
    let slug: String?
    let imageUrl: String?
    let gradient: String?
    let unlockEpiCount: String?
    let status: String?
    let addedDt: String?
    let translation: String?
    let epiUrl: String?
    let tag: String?
    
    // Helper property to safely get drama name
    var safeDramaName: String {
        return dramaName ?? "Unknown Drama"
    }
    
    // Helper property to safely get gradient
    var safeGradient: String {
        return gradient ?? ""
    }
    
    // Helper property to safely get total episodes
    var safeTotalEpisodes: String {
        return totalEpisodes ?? "0"
    }
    
    // Helper property to safely get image URL
    var safeImageUrl: String {
        return imageUrl ?? ""
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case dramaName = "drama_name"
        case dKeywords = "d_keywords"
        case totalEpisodes = "total_episodes"
        case dDesc = "d_desc"
        case slug
        case imageUrl = "image_url"
        case gradient
        case unlockEpiCount = "unlock_epi_count"
        case status
        case addedDt = "added_dt"
        case translation
        case epiUrl = "epi_url"
        case tag
    }
    
    // Custom init to handle missing keys
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Decode all properties as optional
        id = try? container.decode(String.self, forKey: .id)
        dramaName = try? container.decode(String.self, forKey: .dramaName)
        dKeywords = try? container.decode(String.self, forKey: .dKeywords)
        totalEpisodes = try? container.decode(String.self, forKey: .totalEpisodes)
        dDesc = try? container.decode(String.self, forKey: .dDesc)
        slug = try? container.decode(String.self, forKey: .slug)
        imageUrl = try? container.decode(String.self, forKey: .imageUrl)
        gradient = try? container.decode(String.self, forKey: .gradient)
        unlockEpiCount = try? container.decode(String.self, forKey: .unlockEpiCount)
        status = try? container.decode(String.self, forKey: .status)
        addedDt = try? container.decode(String.self, forKey: .addedDt)
        translation = try? container.decode(String.self, forKey: .translation)
        epiUrl = try? container.decode(String.self, forKey: .epiUrl)
        tag = try? container.decode(String.self, forKey: .tag)
    }
}
