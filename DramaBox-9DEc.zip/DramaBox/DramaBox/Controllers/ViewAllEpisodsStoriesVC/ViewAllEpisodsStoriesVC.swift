//
//  ViewAllEpisodsStoriesVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 08/12/25.
//

import UIKit
import SVProgressHUD

class ViewAllEpisodsStoriesVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var dramaId: String?
    var dramaName: String?
    var storiesPlayingViewType: StoriesPlayingViewTypes = .isOpenAllStoriesEpisods
    private var episodes: [EpisodeItem] = []
    
    // Add this public property to receive episodes from StoriesVC
    var allEpisodes: [EpisodeItem] = [] // Add this line
    
    // Properties for pagination
    private var currentPage = 1
    private var isLoading = false
    private var hasMoreData = true
    private var currentPlayingIndex: Int = -1
    private var initialLoadComplete = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        
        // Show loading view before fetching
        showInitialLoading()
        
        // Check if we already have episodes passed from StoriesVC
        if !allEpisodes.isEmpty {
            // Use the pre-loaded episodes
            self.episodes = allEpisodes
            hideInitialLoading()
            tableView.isHidden = false
            tableView.reloadData()
            
            // Auto-play first video
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.playVideoForVisibleCell()
            }
        } else {
            // Fetch episodes from API
            fetchEpisodes()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        
        // Set navigation title
        if let dramaName = dramaName {
            title = dramaName
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        pauseAllVideos()
    }
    
    private func showInitialLoading() {
        SVProgressHUD.show()
    }
    
    private func hideInitialLoading() {
        SVProgressHUD.dismiss()
    }
    
    func setUpUI() {
        settable()
    }
    
    func settable() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(["StoriesPlayingCell"])
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = .black
        self.tableView.isPagingEnabled = true
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.contentInsetAdjustmentBehavior = .never
        
        // Initially hide table view until data loads
        tableView.isHidden = true
    }
    
    private func pauseAllVideos() {
        for cell in tableView.visibleCells {
            if let storiesCell = cell as? StoriesPlayingCell {
                storiesCell.pauseVideo()
            }
        }
        currentPlayingIndex = -1
    }
    
    private func playVideoForVisibleCell() {
        guard let indexPath = getCenterCellIndexPath() else { return }
        
        // If we're already playing this cell, do nothing
        if currentPlayingIndex == indexPath.row { return }
        
        // Pause previously playing video
        if currentPlayingIndex >= 0,
           let previousCell = tableView.cellForRow(at: IndexPath(row: currentPlayingIndex, section: 0)) as? StoriesPlayingCell {
            previousCell.pauseVideo()
        }
        
        // Play new video
        if let currentCell = tableView.cellForRow(at: indexPath) as? StoriesPlayingCell {
            currentCell.playVideo()
            currentPlayingIndex = indexPath.row
            
            // Load more episodes when near the end
            if indexPath.row >= episodes.count - 3 && !isLoading {
                loadMoreEpisodes()
            }
        }
    }
    
    private func getCenterCellIndexPath() -> IndexPath? {
        let center = view.convert(tableView.center, to: tableView)
        return tableView.indexPathForRow(at: center)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension ViewAllEpisodsStoriesVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return episodes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StoriesPlayingCell",
                                                 for: indexPath) as? StoriesPlayingCell ?? StoriesPlayingCell()
        cell.selectionStyle = .none
        
        if indexPath.row < episodes.count {
            let episode = episodes[indexPath.row]
            
            // Configure cell with episode data for isOpenAllStoriesEpisods view
            cell.configureWithEpisode(episode: episode,
                                     viewType: .isOpenAllStoriesEpisods,
                                     dramaName: self.dramaName,
                                     allEpisodes: self.episodes, // Pass all episodes
                                     currentIndex: indexPath.row) // Pass current index
            
            // Handle share button
            cell.shareHandler = { [weak self] in
                self?.shareEpisode(episode)
            }
            
            // Handle save button
            cell.saveHandler = { [weak self] in
                // self?.saveEpisode(episode)
            }
            
            // Handle back button
            cell.backButtonHandler = { [weak self] in
                // self?.dismiss(animated: true)
                self?.navigationController?.popViewController(animated: true)
            }
            
            // Handle episode selection from popup
            cell.episodeSelectedHandler = { [weak self] selectedEpisode in
                // Find the index of the selected episode
                if let index = self?.episodes.firstIndex(where: { $0.epiId == selectedEpisode.epiId }) {
                    // Scroll to that episode
                    let indexPath = IndexPath(row: index, section: 0)
                    tableView.scrollToRow(at: indexPath, at: .middle, animated: false)
                }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.height
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let storiesCell = cell as? StoriesPlayingCell {
            storiesCell.pauseVideo()
            if currentPlayingIndex == indexPath.row {
                currentPlayingIndex = -1
            }
        }
    }
    
    private func shareEpisode(_ episode: EpisodeItem) {
        let shareText = "Watch \(episode.epiName) from \(episode.dName)"
        let activityViewController = UIActivityViewController(activityItems: [shareText], applicationActivities: nil)
        present(activityViewController, animated: true)
    }
}

// MARK: - Scroll autoplay
extension ViewAllEpisodsStoriesVC: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        playVideoForVisibleCell()
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            playVideoForVisibleCell()
        }
    }
}

// MARK: - Api's calling
extension ViewAllEpisodsStoriesVC {
    func fetchEpisodes(isLoadMore: Bool = false) {
        guard let dramaId = dramaId, !dramaId.isEmpty else {
            showAlert(message: "Invalid drama ID")
            return
        }
        
        guard !isLoading, (isLoadMore ? hasMoreData : true) else { return }
        
        isLoading = true
        
        NetworkManager.shared.fetchEpisodes(from: self, dramaId: dramaId, page: currentPage) { [weak self] result in
            guard let self = self else { return }
            
            self.isLoading = false
            
            switch result {
            case .success(let newEpisodes):
                if isLoadMore {
                    self.episodes.append(contentsOf: newEpisodes)
                } else {
                    self.episodes = newEpisodes
                    
                    // Hide initial loading and show table view
                    DispatchQueue.main.async {
                        self.hideInitialLoading()
                        self.tableView.isHidden = false
                        self.initialLoadComplete = true
                    }
                }
                
                // Update pagination state
                self.hasMoreData = !newEpisodes.isEmpty
                if self.hasMoreData {
                    self.currentPage += 1
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    
                    // Auto-play first video if initial load
                    if !isLoadMore && !self.episodes.isEmpty && self.initialLoadComplete {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            self.playVideoForVisibleCell()
                        }
                    }
                }
                
            case .failure(let error):
                print("Error fetching episodes: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.hideInitialLoading()
                    self.tableView.isHidden = false
                    self.showAlert(message: "Failed to load episodes. Please try again.")
                }
            }
        }
    }
    
    func loadMoreEpisodes() {
        guard !isLoading && hasMoreData else { return }
        fetchEpisodes(isLoadMore: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error",
                                      message: message,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
