//
//  TabBarVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import UIKit
import Lottie

class TabBarVC: UITabBarController {
    
    // Unique name so we can find/remove our gradient layer reliably
    private let gradientLayerName = "customTabbarGradientLayer"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabBarIcons()
        setupTabBarAppearance()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Update gradient frame and add corner radius
        updateTabBarAppearance()
    }
    
    private func setupTabBarIcons() {
        // Assuming your view controllers are already set up
        // Set icons for each tab based on their index
        guard let items = tabBar.items, items.count >= 4 else { return }
        
        // Home (index 0)
        items[0].image = UIImage(named: "home_unselected")?.withRenderingMode(.alwaysOriginal)
        items[0].selectedImage = UIImage(named: "home_selected")?.withRenderingMode(.alwaysOriginal)
        items[0].title = "Home".localized(LocalizationService.shared.language)
        
        // Stories (index 1)
        items[1].image = UIImage(named: "stories_selected")?.withRenderingMode(.alwaysOriginal)
        items[1].selectedImage = UIImage(named: "stories_selected")?.withRenderingMode(.alwaysOriginal)
        items[1].title = "Stories".localized(LocalizationService.shared.language)
        
        // My List (index 2)
        items[2].image = UIImage(named: "mylist_unselected")?.withRenderingMode(.alwaysOriginal)
        items[2].selectedImage = UIImage(named: "mylist_selected")?.withRenderingMode(.alwaysOriginal)
        items[2].title = "My List".localized(LocalizationService.shared.language)
        
        // Settings (index 3)
        items[3].image = UIImage(named: "setting_unselected")?.withRenderingMode(.alwaysOriginal)
        items[3].selectedImage = UIImage(named: "setting_selected")?.withRenderingMode(.alwaysOriginal)
        items[3].title = "Settings".localized(LocalizationService.shared.language)
    }
    
    private func setupTabBarAppearance() {
        let appearance = UITabBarAppearance()
        appearance.configureWithTransparentBackground()   // ✅ IMPORTANT
        appearance.backgroundColor = .clear
        appearance.shadowColor = .clear

        // Remove selection indicator
        appearance.selectionIndicatorImage = UIImage()
        
        // Text colors
        appearance.stackedLayoutAppearance.normal.titleTextAttributes = [
            .foregroundColor: UIColor(hex: "#909090") ?? .lightGray,
            .font: UIFont.systemFont(ofSize: 12, weight: .medium)
        ]
        appearance.stackedLayoutAppearance.selected.titleTextAttributes = [
            .foregroundColor: UIColor.white,
            .font: UIFont.systemFont(ofSize: 12, weight: .medium)
        ]

        // Icon colors
        appearance.stackedLayoutAppearance.normal.iconColor = UIColor(hex: "#909090")
        appearance.stackedLayoutAppearance.selected.iconColor = .white

        tabBar.standardAppearance = appearance
        if #available(iOS 15.0, *) {
            tabBar.scrollEdgeAppearance = appearance
        }

        tabBar.backgroundImage = nil
        tabBar.shadowImage = UIImage()
        tabBar.isTranslucent = true
        tabBar.barStyle = .black

        applyLayerGradient()
    }
    
    private func createGradientImage() -> UIImage? {
        let size = CGSize(width: UIScreen.main.bounds.width, height: max(tabBar.bounds.height, 83))
        
        let gradient = CAGradientLayer()
        gradient.frame = CGRect(origin: .zero, size: size)
        gradient.colors = [
            UIColor(hex: "#1A1A1A")?.cgColor ?? UIColor.darkGray.cgColor,
            UIColor(hex: "#161616")?.cgColor ?? UIColor.black.cgColor
        ]
        gradient.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradient.endPoint = CGPoint(x: 0.5, y: 1.0)

        UIGraphicsBeginImageContextWithOptions(size, false, UIScreen.main.scale)
        guard let ctx = UIGraphicsGetCurrentContext() else { return nil }
        gradient.render(in: ctx)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    private func applyLayerGradient() {

        tabBar.layer.sublayers?
            .filter { $0.name == gradientLayerName }
            .forEach { $0.removeFromSuperlayer() }

        let gradient = CAGradientLayer()
        gradient.name = gradientLayerName
        gradient.frame = tabBar.bounds
        gradient.cornerRadius = 20
        gradient.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        gradient.colors = [
            UIColor(hex: "#2E2E2E")!.cgColor,
            UIColor(hex: "#161616")!.cgColor
        ]
        gradient.startPoint = CGPoint(x: 0.5, y: 0)
        gradient.endPoint = CGPoint(x: 0.5, y: 1)

        tabBar.layer.insertSublayer(gradient, at: 0)

        tabBar.layer.cornerRadius = 20
        tabBar.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        tabBar.layer.masksToBounds = true   // ✅ MUST USE masksToBounds
    }

    
    private func updateTabBarAppearance() {
        tabBar.layer.sublayers?
            .filter { $0.name == gradientLayerName }
            .forEach {
                $0.frame = tabBar.bounds
                $0.cornerRadius = 20
            }
    }
}

// UIColor extension for hex colors
extension UIColor {
    convenience init?(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        
        var rgb: UInt64 = 0
        
        guard Scanner(string: hexSanitized).scanHexInt64(&rgb) else {
            return nil
        }
        
        let length = hexSanitized.count
        
        if length == 6 {
            self.init(
                red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0,
                green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0,
                blue: CGFloat(rgb & 0x0000FF) / 255.0,
                alpha: 1.0
            )
        } else {
            return nil
        }
    }
}
