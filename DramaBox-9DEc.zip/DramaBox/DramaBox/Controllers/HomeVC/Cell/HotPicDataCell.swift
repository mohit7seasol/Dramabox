//
//  HotPicDataCell.swift
//  DramaBox
//
//  Created by DREAMWORLD on 05/12/25.
//

import UIKit
import SDWebImage

class HotPicDataCell: UICollectionViewCell {
    @IBOutlet weak var preViewImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var likeCountLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Clear backgrounds
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .clear
        
        // Set corner radius only for image
        preViewImageView.layer.cornerRadius = 8
        preViewImageView.clipsToBounds = true
        preViewImageView.contentMode = .scaleAspectFill
        
        // Set label colors
        nameLabel.textColor = .white
        likeCountLabel.textColor = .white
        
        // Set like count label styling
        likeCountLabel.font = UIFont.systemFont(ofSize: 12, weight: .medium)
        
        nameLabel.font = FontManager.shared.font(for: .roboto, size: 16.0)
        likeCountLabel.font = FontManager.shared.font(for: .roboto, size: 14.0)
    }
    
    func configure(with drama: DramaItem) {
        nameLabel.text = drama.dramaName
        
        if let imageUrl = drama.imageUrl, let url = URL(string: imageUrl) {
            preViewImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "placeholder"))
        }
    }
}
