//
//  EpisodesListCell.swift
//  DramaBox
//
//  Created by DREAMWORLD on 09/12/25.
//

import UIKit


class EpisodesListCell: UICollectionViewCell {

    @IBOutlet weak var parentView: UIView!
    @IBOutlet weak var episodNoLabel: UILabel!
    @IBOutlet weak var isPremiumImageView: UIImageView!
    
    private var gradientLayer: CAGradientLayer?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        gradientLayer?.removeFromSuperlayer()
        gradientLayer = nil
        parentView.backgroundColor = .clear
        isPremiumImageView.isHidden = true
    }
    
    private func setupUI() {
        // Make cell square and rounded
        parentView.layer.cornerRadius = 8
        parentView.layer.masksToBounds = true
        
        // Setup premium image
        isPremiumImageView.isHidden = true
        isPremiumImageView.contentMode = .scaleAspectFit
        
        // Setup label
        episodNoLabel.textColor = .white
        episodNoLabel.textAlignment = .center
        episodNoLabel.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        episodNoLabel.adjustsFontSizeToFitWidth = true
        episodNoLabel.minimumScaleFactor = 0.5
    }
    
    func applyGradientBackground(topColor: UIColor, bottomColor: UIColor) {
        // Remove existing gradient
        gradientLayer?.removeFromSuperlayer()
        
        // Create new gradient
        gradientLayer = CAGradientLayer()
        gradientLayer?.frame = parentView.bounds
        gradientLayer?.colors = [topColor.cgColor, bottomColor.cgColor]
        gradientLayer?.startPoint = CGPoint(x: 0.5, y: 0)
        gradientLayer?.endPoint = CGPoint(x: 0.5, y: 1)
        gradientLayer?.cornerRadius = 8
        
        // Insert gradient at the bottom of parentView's layer stack
        parentView.layer.insertSublayer(gradientLayer!, at: 0)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer?.frame = parentView.bounds
    }
    
    func configure(isSelected: Bool, isPremium: Bool, episodeNumber: Int) {
        episodNoLabel.text = "\(episodeNumber)"
        
        if isSelected {
            // Selected cell - solid purple color
            gradientLayer?.removeFromSuperlayer()
            gradientLayer = nil
            parentView.backgroundColor = UIColor(hex: "#A12BFF")
            episodNoLabel.textColor = .white
        } else {
            // Normal cell - gradient background
            parentView.backgroundColor = .clear
            applyGradientBackground(
                topColor:   #colorLiteral(red: 0.1921568627, green: 0.1882352941, blue: 0.1960784314, alpha: 1),
                bottomColor: #colorLiteral(red: 0.1386529207, green: 0.1336191893, blue: 0.1386296749, alpha: 1) // 5% opacity white
            )
            episodNoLabel.textColor = .white
        }
        
        // Show premium icon for locked episodes
        isPremiumImageView.isHidden = !isPremium
        
        // Position premium icon in top-right corner
        if !isPremiumImageView.isHidden {
            isPremiumImageView.frame = CGRect(
                x: parentView.bounds.width - 20,
                y: 5,
                width: 15,
                height: 15
            )
        }
    }
}
