//
//  StoriesPlayingCell.swift
//  DramaBox
//
//  Created by DREAMWORLD on 08/12/25.
//

import UIKit
import AVFoundation
import SDWebImage
import FINNBottomSheet

class StoriesPlayingCell: UITableViewCell {

    @IBOutlet weak var appTitleHeaderView: UIView!
    @IBOutlet weak var navigationTitleView: UIView!
    @IBOutlet weak var appTitleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var navigationTitleLabel: UILabel!
    @IBOutlet weak var moreButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var userProfieInfoView: UIView!
    @IBOutlet weak var userProfileImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var storieDetailsLabel: UILabel!
    @IBOutlet weak var enjoyFullStoriesView: UIView!
    @IBOutlet weak var enjoyFullStoriesLabel: UILabel!
    @IBOutlet weak var enjoyFullStoriesButton: UIButton!
    @IBOutlet weak var videoSliderView: UIView!
    @IBOutlet weak var videoSlider: UISlider!
    @IBOutlet weak var startDurationLabel: UILabel!
    @IBOutlet weak var endDurationLabel: UILabel!
    @IBOutlet weak var allEpisodsButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var storiesThumbImageView: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var storieDetailsLabelHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var videoSliderViewHeightConstant: NSLayoutConstraint!
    @IBOutlet weak var fullStoryViewHeightConstant: NSLayoutConstraint!
    
    // Outlets All Episods Bottom View popup
    @IBOutlet weak var allEpisodsView: UIView!
    @IBOutlet weak var videoSpeedAndQualityView: UIView!
    @IBOutlet weak var allEpisodsUserProfileImageView: UIImageView!
    @IBOutlet weak var allEpisodsUserNameLabel: UILabel!
    @IBOutlet weak var allEpisodsPopUpViewCloseButton: UIButton!
    @IBOutlet weak var totalEpisodsCountTitleLabel: UILabel! // Like: Total 50 Episodes
    @IBOutlet weak var allEpisodsCollectionView: UICollectionView!
    @IBOutlet weak var allEpisodsStartToEndCountLabel: UILabel! // Like: 1-40
    
    // Outlets videoSpeedAndQualityView View popup
    @IBOutlet weak var videoSpeedCloseButton: UIButton!
    @IBOutlet weak var playSpeedExpandButton: UIButton!
    @IBOutlet weak var displayVideoQualityExpandButton: UIButton!
    
    @IBOutlet weak var zeroPointSeventyFiveXSpeedButton: UIButton! // 0.75X
    @IBOutlet weak var oneXSpeedButton: UIButton! // 1.0X
    @IBOutlet weak var onePointFiveXSpeedButton: UIButton! // 1.5X
    @IBOutlet weak var twoXSpeedButton: UIButton! // 2.0X
    @IBOutlet weak var playSpeedOptionsHeightConstant: NSLayoutConstraint!
    
    @IBOutlet weak var twoHundredFortyPVideoQualityButton: UIButton! // 240P
    @IBOutlet weak var fourHundredEighyPVideoQualityButton: UIButton! // 480P
    @IBOutlet weak var seventHundredTwentyPVideoQualityButton: UIButton! // 720p
    @IBOutlet weak var videoQualityHeightConstant: NSLayoutConstraint!
    
    @IBOutlet weak var scrollViewDisplayVideoQualityWithSpeed: UIScrollView!
    
    
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    private var isVideoPlaying = false
    private var currentDrama: DramaItem?
    private var currentEpisode: EpisodeItem?
    private var isStoryDetailsExpanded = false
    
    // New properties
    private var allEpisodes: [EpisodeItem] = []
    private var selectedEpisodeIndex: Int = 0
    private var isPlaySpeedExpanded: Bool = false
    private var isVideoQualityExpanded: Bool = false
    private var selectedSpeedIndex: Int = 0 // 0: 0.75X, 1: 1X, 2: 1.5X, 3: 2X
    private var selectedQualityIndex: Int = 0 // 0: 240P, 1: 480P, 2: 720P
    private var isSubscribed: Bool = false // Will be updated from Subscribe.get()
    
    // Handlers
    var enjoyFullStoriesHandler: (() -> Void)?
    var storyDetailsTappedHandler: (() -> Void)?
    var shareHandler: (() -> Void)?
    var saveHandler: (() -> Void)?
    var backButtonHandler: (() -> Void)?
    var moreButtonHandler: (() -> Void)?
    var episodeSelectedHandler: ((EpisodeItem) -> Void)?
    var allEpisodesForDrama: [EpisodeItem] = []
    var storiesPlayingViewType: StoriesPlayingViewTypes = .isOpenStories
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setCellUI()
        setupGestureRecognizers()
        setupControls()
        setupStoryDetailsLabel()
        setupButtonActions()
        setupCollectionViews()
        setupPopupViews()
        setupSpeedAndQualityButtons()
        
        // Update scroll view content size after setup
        DispatchQueue.main.async {
            self.updateScrollViewContentSize()
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        playerLayer?.frame = mainView.bounds
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        resetVideo()
        currentDrama = nil
        currentEpisode = nil
        hideLoading()
        isStoryDetailsExpanded = false
        updateStoryDetailsLabel()
        hideAllPopups()
    }
    
    func setCellUI() {
        mainView.backgroundColor = .black
        
        // Setup user profile image
        userProfileImageView.layer.cornerRadius = userProfileImageView.frame.width / 2
        userProfileImageView.clipsToBounds = true
        userProfileImageView.image = UIImage(named: "user_placeholder")
        
        // Setup loading indicator
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.color = .white
        loadingIndicator.style = .large
        
        // Setup play/pause button
        playButton.isHidden = true
        playButton.tintColor = .white
        playButton.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        playButton.layer.cornerRadius = 30
        playButton.layer.masksToBounds = true
        playButton.setImage(UIImage(named: "play"), for: .normal)
        
        // Setup story details label
        storieDetailsLabel.textColor = .white
        storieDetailsLabel.numberOfLines = 2 // Initially 2 lines
        storieDetailsLabel.isUserInteractionEnabled = true
        
        // Setup slider
        setupSlider()
    }
    
    private func setupCollectionViews() {
        // Setup all episodes collection view
        allEpisodsCollectionView.delegate = self
        allEpisodsCollectionView.dataSource = self
        allEpisodsCollectionView.register(UINib(nibName: "EpisodesListCell", bundle: nil), forCellWithReuseIdentifier: "EpisodesListCell")
        allEpisodsCollectionView.backgroundColor = .clear
        
        // Setup flow layout for vertical scrolling with square cells
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 5
        allEpisodsCollectionView.collectionViewLayout = layout
    }
    
    private func setupPopupViews() {
        // Initially hide popup views
        allEpisodsView.isHidden = true
        videoSpeedAndQualityView.isHidden = true
        
        // Add tap gesture to close popups when tapping outside
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handlePopupBackgroundTap(_:)))
        tapGesture.delegate = self
        allEpisodsView.addGestureRecognizer(tapGesture)
        videoSpeedAndQualityView.addGestureRecognizer(tapGesture)
        
        // Setup close buttons
        allEpisodsPopUpViewCloseButton.addTarget(self, action: #selector(closeAllEpisodsPopup), for: .touchUpInside)
        videoSpeedCloseButton.addTarget(self, action: #selector(closeVideoSpeedPopup), for: .touchUpInside)
    }
    
    private func setupSpeedAndQualityButtons() {
        // Set initial button states
        isPlaySpeedExpanded = false
        isVideoQualityExpanded = false
        
        // Initially hide the expandable buttons
        oneXSpeedButton.isHidden = true
        onePointFiveXSpeedButton.isHidden = true
        twoXSpeedButton.isHidden = true
        fourHundredEighyPVideoQualityButton.isHidden = true
        seventHundredTwentyPVideoQualityButton.isHidden = true
        
        // Set initial heights
        playSpeedOptionsHeightConstant.constant = 34
        videoQualityHeightConstant.constant = 34
        
        // Add button actions for speed
        zeroPointSeventyFiveXSpeedButton.addTarget(self, action: #selector(speedButtonTapped(_:)), for: .touchUpInside)
        oneXSpeedButton.addTarget(self, action: #selector(speedButtonTapped(_:)), for: .touchUpInside)
        onePointFiveXSpeedButton.addTarget(self, action: #selector(speedButtonTapped(_:)), for: .touchUpInside)
        twoXSpeedButton.addTarget(self, action: #selector(speedButtonTapped(_:)), for: .touchUpInside)
        
        // Add button actions for quality
        twoHundredFortyPVideoQualityButton.addTarget(self, action: #selector(qualityButtonTapped(_:)), for: .touchUpInside)
        fourHundredEighyPVideoQualityButton.addTarget(self, action: #selector(qualityButtonTapped(_:)), for: .touchUpInside)
        seventHundredTwentyPVideoQualityButton.addTarget(self, action: #selector(qualityButtonTapped(_:)), for: .touchUpInside)
        
        // Set initial button colors
        updateSpeedButtons()
        updateQualityButtons()
    }
    
    private func updateSpeedButtons() {
        // Update button colors
        let selectedColor = UIColor.white
        let unselectedColor = UIColor(hex: "#878787")
        
        zeroPointSeventyFiveXSpeedButton.setTitleColor(selectedSpeedIndex == 0 ? selectedColor : unselectedColor, for: .normal)
        oneXSpeedButton.setTitleColor(selectedSpeedIndex == 1 ? selectedColor : unselectedColor, for: .normal)
        onePointFiveXSpeedButton.setTitleColor(selectedSpeedIndex == 2 ? selectedColor : unselectedColor, for: .normal)
        twoXSpeedButton.setTitleColor(selectedSpeedIndex == 3 ? selectedColor : unselectedColor, for: .normal)
        
        // Update play speed in player
        updatePlaybackSpeed()
    }
    
    private func updateQualityButtons() {
        // Update button colors
        let selectedColor = UIColor.white
        let unselectedColor = UIColor(hex: "#878787")
        
        twoHundredFortyPVideoQualityButton.setTitleColor(selectedQualityIndex == 0 ? selectedColor : unselectedColor, for: .normal)
        fourHundredEighyPVideoQualityButton.setTitleColor(selectedQualityIndex == 1 ? selectedColor : unselectedColor, for: .normal)
        seventHundredTwentyPVideoQualityButton.setTitleColor(selectedQualityIndex == 2 ? selectedColor : unselectedColor, for: .normal)
    }
    
    private func updatePlaybackSpeed() {
        guard let player = player else { return }
        
        var speed: Float = 1.0
        switch selectedSpeedIndex {
        case 0: speed = 0.75
        case 1: speed = 1.0
        case 2: speed = 1.5
        case 3: speed = 2.0
        default: speed = 1.0
        }
        
        player.rate = speed
    }
    
    private func updateVideoQuality() {
        // This will be called when quality changes
        // You'll need to implement the logic to switch video URL based on quality
        guard let episode = currentEpisode else { return }
        
        var videoUrlString = ""
        switch selectedQualityIndex {
        case 0: // 240P
            videoUrlString = episode.video240p
        case 1: // 480P
            videoUrlString = episode.video480p
        case 2: // 720P
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
        default:
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
        }
        
        if !videoUrlString.isEmpty, let url = URL(string: videoUrlString) {
            // Switch to new video URL
            switchToNewVideo(url: url)
        }
    }
    
    private func switchToNewVideo(url: URL) {
        resetVideo()
        setupPlayer(with: url)
        
        // If video was playing, start playing again
        if isVideoPlaying {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.playVideo()
            }
        }
    }
    
    private func setupButtonActions() {
        // Setup button actions
        enjoyFullStoriesButton.addTarget(self, action: #selector(enjoyFullStoriesTapped), for: .touchUpInside)
        shareButton.addTarget(self, action: #selector(shareButtonTapped), for: .touchUpInside)
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
        playButton.addTarget(self, action: #selector(togglePlayPause), for: .touchUpInside)
        allEpisodsButton.addTarget(self, action: #selector(allEpisodsViewButtonAction), for: .touchUpInside)
    }
    
    private func setupSlider() {
        videoSlider.minimumTrackTintColor = .white
        videoSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.3)
        videoSlider.minimumValue = 0
        videoSlider.maximumValue = 1
        
        let thumbSize: CGFloat = 20
        let thumbImage = createThumbImage(size: thumbSize, color: .white)
        videoSlider.setThumbImage(thumbImage, for: .normal)
        videoSlider.setThumbImage(thumbImage, for: .highlighted)
        
        videoSlider.addTarget(self, action: #selector(sliderValueChanged(_:)), for: .valueChanged)
    }
    
    private func createThumbImage(size: CGFloat, color: UIColor) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: size, height: size))
        return renderer.image { context in
            color.setFill()
            context.cgContext.fillEllipse(in: CGRect(x: 0, y: 0, width: size, height: size))
            UIColor.black.withAlphaComponent(0.3).setFill()
            let innerSize = size - 6
            context.cgContext.fillEllipse(in: CGRect(x: 3, y: 3, width: innerSize, height: innerSize))
        }
    }
    
    private func setupControls() {
        playButton.addTarget(self, action: #selector(togglePlayPause), for: .touchUpInside)
    }
    
    private func setupGestureRecognizers() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        mainView.addGestureRecognizer(tapGesture)
        mainView.isUserInteractionEnabled = true
        
        // Tap gesture for story details label
        let detailsTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleStoryDetailsTap))
        storieDetailsLabel.addGestureRecognizer(detailsTapGesture)
    }
    
    private func setupStoryDetailsLabel() {
        updateStoryDetailsLabel()
    }
    
    private func updateStoryDetailsLabel() {
        guard let text = storieDetailsLabel.text else {
            storieDetailsLabelHeightConstraint.constant = 0
            return
        }
        
        if isStoryDetailsExpanded {
            // Expanded state
            storieDetailsLabel.numberOfLines = 0
            storieDetailsLabelHeightConstraint.constant = calculateLabelHeight(for: text, width: storieDetailsLabel.frame.width)
        } else {
            // Collapsed state
            storieDetailsLabel.numberOfLines = 2
            storieDetailsLabelHeightConstraint.constant = calculateLabelHeight(for: text, width: storieDetailsLabel.frame.width, maxLines: 2)
        }
    }
    
    private func calculateLabelHeight(for text: String, width: CGFloat, maxLines: Int = 0) -> CGFloat {
        let label = UILabel()
        label.numberOfLines = maxLines
        label.font = storieDetailsLabel.font
        label.text = text
        
        let maxSize = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let requiredSize = label.sizeThatFits(maxSize)
        return requiredSize.height
    }
    
    // MARK: - Configuration Methods
    
    func configureWithDrama(drama: DramaItem, viewType: StoriesPlayingViewTypes, allEpisodes: [EpisodeItem] = []) {
        currentDrama = drama
        self.allEpisodesForDrama = allEpisodes // Store episodes for this drama
        
        // Update UI based on view type
        updateUIForViewType(viewType)
        self.storiesPlayingViewType = viewType
        // Set data for viewType == isOpenStories
        if viewType == .isOpenStories {
            
            // Fill user info
            userNameLabel.text = drama.dramaName ?? "Unknown"
            
            // Fill story details
            if let dDesc = drama.dDesc, !dDesc.isEmpty {
                storieDetailsLabel.text = dDesc
            } else {
                storieDetailsLabel.text = drama.dramaName ?? "No description available"
            }
            
            // Fill thumbnail image
            if let imageUrl = drama.imageUrl, let url = URL(string: imageUrl) {
                storiesThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "video_placeholder"))
                userProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
                
                // Also set for all episodes popup
                allEpisodsUserProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
                allEpisodsUserProfileImageView.layer.cornerRadius = allEpisodsUserProfileImageView.frame.width / 2
                allEpisodsUserProfileImageView.clipsToBounds = true
            }
            
            // Set all episodes popup user info
            allEpisodsUserNameLabel.text = drama.dramaName ?? "Unknown"
            
            // Set total episodes count for this drama
            let totalEpisodes = allEpisodes.count
            updateEpisodeCountLabels(totalEpisodes: totalEpisodes)
            
            // Reload episodes collection view
            self.allEpisodes = allEpisodes
            allEpisodsCollectionView.reloadData()
        }
        
        // Reset story details to collapsed state
        isStoryDetailsExpanded = false
        updateStoryDetailsLabel()
        
        // Setup video player with epi_url
        setupVideoPlayerWithDrama(drama: drama)
    }
    private func updateEpisodeCountLabels(totalEpisodes: Int) {
        // Set total episodes count with white color for number
        let attributedString = NSMutableAttributedString(string: "Total \(totalEpisodes) Episodes")
        let range = (attributedString.string as NSString).range(of: "\(totalEpisodes)")
        attributedString.addAttribute(.foregroundColor, value: UIColor.white, range: range)
        totalEpisodsCountTitleLabel.attributedText = attributedString
        
        // Set start to end count
        allEpisodsStartToEndCountLabel.text = "1-\(totalEpisodes)"
    }
    func configureWithEpisode(episode: EpisodeItem, viewType: StoriesPlayingViewTypes, dramaName: String? = nil, allEpisodes: [EpisodeItem] = [], currentIndex: Int = 0) {
        currentEpisode = episode
        self.allEpisodes = allEpisodes
        self.selectedEpisodeIndex = currentIndex
        self.storiesPlayingViewType = viewType
        
        // Update subscription status (you'll need to implement Subscribe.get())
        // self.isSubscribed = Subscribe.get()
        // For testing, set to false to see premium behavior
        self.isSubscribed = Subscribe.get() // Change this to Subscribe.get() when ready
        
        // Update UI based on view type
        updateUIForViewType(viewType)
        
        // Set data for viewType == isOpenAllStoriesEpisods
        if viewType == .isOpenAllStoriesEpisods {
            // Set navigation title
            navigationTitleLabel.text = dramaName ?? episode.dName
            
            // Fill user info
            userNameLabel.text = episode.dName
            
            // Fill thumbnail image
            if !episode.thumbnails.isEmpty, let url = URL(string: episode.thumbnails) {
                storiesThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "video_placeholder"))
            }
            
            // Fill user profile image
            if !episode.dImage.isEmpty, let url = URL(string: episode.dImage) {
                userProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
                
                // Also set for all episodes popup
                allEpisodsUserProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
                allEpisodsUserProfileImageView.layer.cornerRadius = allEpisodsUserProfileImageView.frame.width / 2
                allEpisodsUserProfileImageView.clipsToBounds = true
            }
            
            // Set all episodes popup user info
            allEpisodsUserNameLabel.text = dramaName ?? episode.dName
            
            // Set total episodes count
            let totalEpisodes = allEpisodes.count
            updateEpisodeCountLabels(totalEpisodes: totalEpisodes)
            
            // Reset duration labels (will be updated when video loads)
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
            
            // Reload episodes collection view
            allEpisodsCollectionView.reloadData()
            
            // Scroll to current episode
            if currentIndex < allEpisodes.count {
                let indexPath = IndexPath(item: currentIndex, section: 0)
                allEpisodsCollectionView.scrollToItem(at: indexPath, at: .centeredVertically, animated: false)
            }
        }
        
        // Setup video player with episode video
        setupVideoPlayerWithEpisode(episode: episode)
    }
    
    private func updateUIForViewType(_ viewType: StoriesPlayingViewTypes) {
        switch viewType {
        case .isOpenStories:
            // Show appTitleHeaderView and hide navigationTitleView
            appTitleHeaderView.isHidden = false
            navigationTitleView.isHidden = true
            
            // Show userProfieInfoView, storieDetailsLabel, enjoyFullStoriesView
            // Hide videoSliderView
            userProfieInfoView.isHidden = false
            storieDetailsLabel.isHidden = false
            enjoyFullStoriesView.isHidden = false
            videoSliderView.isHidden = true
            
            videoSliderViewHeightConstant.constant = 0
            storieDetailsLabelHeightConstraint.constant = 34
        case .isOpenAllStoriesEpisods:
            // Hide appTitleHeaderView and show navigationTitleView
            appTitleHeaderView.isHidden = true
            navigationTitleView.isHidden = false
            
            // Show userProfieInfoView, videoSliderView
            // Hide storieDetailsLabel, enjoyFullStoriesView
            userProfieInfoView.isHidden = false
            videoSliderView.isHidden = false
            storieDetailsLabel.isHidden = true
            enjoyFullStoriesView.isHidden = true
            
            fullStoryViewHeightConstant.constant = 0
            storieDetailsLabelHeightConstraint.constant = 0
            videoSliderViewHeightConstant.constant = 70
        }
    }
    
    private func setupVideoPlayerWithDrama(drama: DramaItem) {
        resetVideo()
        
        // Get video URL from drama (epi_url)
        guard let videoUrlString = drama.epiUrl, !videoUrlString.isEmpty,
              let url = URL(string: videoUrlString) else {
            // If no video URL, just show image
            storiesThumbImageView.isHidden = false
            playButton.isHidden = true
            return
        }
        
        setupPlayer(with: url)
    }
    
    private func setupVideoPlayerWithEpisode(episode: EpisodeItem) {
        resetVideo()
        
        // Get video URL based on selected quality
        var videoUrlString = ""
        switch selectedQualityIndex {
        case 0: // 240P
            videoUrlString = episode.video240p
        case 1: // 480P
            videoUrlString = episode.video480p
        case 2: // 720P
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
        default:
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
        }
        
        guard !videoUrlString.isEmpty, let url = URL(string: videoUrlString) else {
            storiesThumbImageView.isHidden = false
            playButton.isHidden = true
            return
        }
        
        setupPlayer(with: url)
    }
    
    private func setupPlayer(with url: URL) {
        showLoading()
        
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = mainView.bounds
        playerLayer?.videoGravity = .resizeAspectFill
        
        if let layer = playerLayer {
            mainView.layer.insertSublayer(layer, below: storiesThumbImageView.layer)
        }
        
        // Set initial playback speed
        updatePlaybackSpeed()
        
        // Add observer for video end
        NotificationCenter.default.addObserver(self,
                                             selector: #selector(videoDidEnd),
                                             name: .AVPlayerItemDidPlayToEndTime,
                                             object: playerItem)
        
        // Add observers for player status
        playerItem.addObserver(self, forKeyPath: "status", options: [.new], context: nil)
        playerItem.addObserver(self, forKeyPath: "duration", options: [.new], context: nil)
        
        // Add time observer for slider updates and duration labels
        player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.1, preferredTimescale: CMTimeScale(NSEC_PER_SEC)), queue: .main) { [weak self] time in
            self?.updateSliderPosition()
            self?.updateDurationLabels()
        }
    }
    
    private func updateSliderPosition() {
        guard let player = player,
              let playerItem = player.currentItem else {
            videoSlider.value = 0
            return
        }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else {
            videoSlider.value = 0
            return
        }
        
        let currentTime = CMTimeGetSeconds(player.currentTime())
        let totalDuration = CMTimeGetSeconds(duration)
        
        videoSlider.value = Float(currentTime / totalDuration)
    }
    
    private func updateDurationLabels() {
        guard let player = player,
              let playerItem = player.currentItem else {
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
            return
        }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else {
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
            return
        }
        
        // Update current time
        let currentTime = CMTimeGetSeconds(player.currentTime())
        startDurationLabel.text = formatTime(currentTime)
        
        // Update total duration
        let totalDuration = CMTimeGetSeconds(duration)
        endDurationLabel.text = formatTime(totalDuration)
    }
    
    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite && !seconds.isNaN else {
            return "0:00"
        }
        
        let minutes = Int(seconds) / 60
        let remainingSeconds = Int(seconds) % 60
        return String(format: "%d:%02d", minutes, remainingSeconds)
    }
    
    func playVideo() {
        guard let player = player else { return }
        
        if !isVideoPlaying {
            storiesThumbImageView.isHidden = true
            player.play()
            isVideoPlaying = true
            playButton.setImage(UIImage(named: "pause"), for: .normal)
            playButton.isHidden = false
        }
    }
    
    func pauseVideo() {
        guard let player = player, isVideoPlaying else { return }
        
        player.pause()
        isVideoPlaying = false
        playButton.setImage(UIImage(named: "play"), for: .normal)
        playButton.isHidden = false
    }
    
    private func resetVideo() {
        pauseVideo()
        
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: nil)
        
        if let playerItem = player?.currentItem {
            playerItem.removeObserver(self, forKeyPath: "status")
            playerItem.removeObserver(self, forKeyPath: "duration")
        }
        
        playerLayer?.removeFromSuperlayer()
        player = nil
        playerLayer = nil
        storiesThumbImageView.isHidden = false
        videoSlider.value = 0
        startDurationLabel.text = "0:00"
        endDurationLabel.text = "0:00"
    }
    
    // MARK: - Loading
    
    private func showLoading() {
        loadingIndicator.startAnimating()
        loadingIndicator.isHidden = false
        playButton.isHidden = true
    }
    
    private func hideLoading() {
        loadingIndicator.stopAnimating()
        loadingIndicator.isHidden = true
    }
    
    // MARK: - Popup Management
    
    private func showAllEpisodsPopup() {
        allEpisodsView.isHidden = false
        allEpisodsView.alpha = 0
        
        UIView.animate(withDuration: 0.3) {
            self.allEpisodsView.alpha = 1
        }
    }
    
    private func showVideoSpeedPopup() {
        videoSpeedAndQualityView.isHidden = false
        videoSpeedAndQualityView.alpha = 0
        
        // Ensure content size is updated before showing
        updateScrollViewContentSize()
        
        UIView.animate(withDuration: 0.3) {
            self.videoSpeedAndQualityView.alpha = 1
        }
    }
    
    private func hideAllPopups() {
        if !allEpisodsView.isHidden {
            closeAllEpisodsPopup()
        }
        if !videoSpeedAndQualityView.isHidden {
            closeVideoSpeedPopup()
        }
    }
    
    @objc private func closeAllEpisodsPopup() {
        UIView.animate(withDuration: 0.3, animations: {
            self.allEpisodsView.alpha = 0
        }) { _ in
            self.allEpisodsView.isHidden = true
        }
    }
    
    @objc private func closeVideoSpeedPopup() {
        UIView.animate(withDuration: 0.3, animations: {
            self.videoSpeedAndQualityView.alpha = 0
        }) { _ in
            self.videoSpeedAndQualityView.isHidden = true
        }
    }
    
    @objc private func handlePopupBackgroundTap(_ gesture: UITapGestureRecognizer) {
        let location = gesture.location(in: allEpisodsView)
        let videoLocation = gesture.location(in: videoSpeedAndQualityView)
        
        // Check if tap is on the background (not on the content view)
        if ((allEpisodsView.subviews.first?.frame.contains(location)) == nil) {
            closeAllEpisodsPopup()
        }
        if ((videoSpeedAndQualityView.subviews.first?.frame.contains(videoLocation)) == nil) {
            closeVideoSpeedPopup()
        }
    }
    
    // MARK: - Button Actions
    
    @objc private func togglePlayPause() {
        if isVideoPlaying {
            pauseVideo()
        } else {
            playVideo()
        }
    }
    
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        togglePlayPause()
    }
    
    @objc private func handleStoryDetailsTap() {
        isStoryDetailsExpanded = !isStoryDetailsExpanded
        updateStoryDetailsLabel()
        
        // Notify view controller to update cell height
        storyDetailsTappedHandler?()
    }
    
    @objc private func enjoyFullStoriesTapped() {
        enjoyFullStoriesHandler?()
    }
    
    @objc private func shareButtonTapped() {
        shareHandler?()
    }
    
    @objc private func saveButtonTapped() {
        saveHandler?()
    }
    
    @objc private func backButtonTapped() {
        backButtonHandler?()
    }
    
    @objc private func moreButtonTapped() {
        moreButtonHandler?()
    }
    
    @objc private func sliderValueChanged(_ sender: UISlider) {
        guard let player = player,
              let playerItem = player.currentItem else { return }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else { return }
        
        let totalDuration = CMTimeGetSeconds(duration)
        let targetTime = Double(sender.value) * totalDuration
        let seekTime = CMTime(seconds: targetTime, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        
        player.seek(to: seekTime, toleranceBefore: .zero, toleranceAfter: .zero)
        
        // Update current time label when slider changes
        startDurationLabel.text = formatTime(targetTime)
    }
    
    @objc private func videoDidEnd() {
        // For stories, you might want to auto-advance to next story
        // For episodes, loop or go to next episode
        player?.seek(to: .zero)
        player?.play()
    }
    
    @objc private func speedButtonTapped(_ sender: UIButton) {
        switch sender {
        case zeroPointSeventyFiveXSpeedButton:
            selectedSpeedIndex = 0
        case oneXSpeedButton:
            selectedSpeedIndex = 1
        case onePointFiveXSpeedButton:
            selectedSpeedIndex = 2
        case twoXSpeedButton:
            selectedSpeedIndex = 3
        default:
            selectedSpeedIndex = 0
        }
        
        updateSpeedButtons()
    }
    
    @objc private func qualityButtonTapped(_ sender: UIButton) {
        switch sender {
        case twoHundredFortyPVideoQualityButton:
            selectedQualityIndex = 0
        case fourHundredEighyPVideoQualityButton:
            selectedQualityIndex = 1
        case seventHundredTwentyPVideoQualityButton:
            selectedQualityIndex = 2
        default:
            selectedQualityIndex = 0
        }
        
        updateQualityButtons()
        updateVideoQuality()
    }
    
    // MARK: - KVO
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let playerItem = object as? AVPlayerItem else { return }
        
        if keyPath == "status" {
            switch playerItem.status {
            case .readyToPlay:
                hideLoading()
                playButton.isHidden = false
                // Update duration labels when video is ready
                updateDurationLabels()
            case .failed:
                hideLoading()
                storiesThumbImageView.isHidden = false
                playButton.isHidden = true
            default:
                break
            }
        } else if keyPath == "duration" {
            // Update end duration label when duration is known
            updateDurationLabels()
        }
    }
    
    deinit {
        resetVideo()
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
extension StoriesPlayingCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return allEpisodes.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "EpisodesListCell", for: indexPath) as! EpisodesListCell
        
        let episodeNumber = indexPath.item + 1
        
        // Check if this is the selected episode
        let isSelected = indexPath.item == selectedEpisodeIndex
        
        // Check if this episode is premium (locked for non-subscribers)
        // For .isOpenStories view, always show all episodes as available
        // For .isOpenAllStoriesEpisods view, apply subscription logic
        var isPremium = false
        if storiesPlayingViewType == .isOpenAllStoriesEpisods && !isSubscribed && indexPath.item >= 3 {
            isPremium = true
        }
        
        cell.configure(isSelected: isSelected, isPremium: isPremium, episodeNumber: episodeNumber)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Calculate width for 5 cells per row with 5px left/right spacing
        let collectionWidth = collectionView.frame.width
        let totalSpacing: CGFloat = (5 * 2) + (4 * 5) // 5px left + 5px right + 4 inter-item spacings of 5px each
        let availableWidth = collectionWidth - totalSpacing
        let cellWidth = availableWidth / 5
        
        // Make it square (width = height)
        return CGSize(width: cellWidth, height: cellWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 5, bottom: 10, right: 5)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Check if cell is selectable based on subscription
        if storiesPlayingViewType == .isOpenAllStoriesEpisods && !isSubscribed && indexPath.item >= 3 {
            // Show subscription prompt or do nothing
            print("Episode locked. Please subscribe.")
            return
        }
        
        selectedEpisodeIndex = indexPath.item
        collectionView.reloadData()
        
        // Scroll to selected item
        collectionView.scrollToItem(at: indexPath, at: .centeredVertically, animated: true)
        
        // Get the selected episode
        let selectedEpisode = allEpisodes[indexPath.item]
        
        // Notify about episode selection
        episodeSelectedHandler?(selectedEpisode)
        
        // Close popup after selection
        closeAllEpisodsPopup()
    }
}

// MARK: - UIGestureRecognizerDelegate
extension StoriesPlayingCell {
    override func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        // Allow tap to pass through to buttons and collection view
        let location = touch.location(in: allEpisodsView)
        let videoLocation = touch.location(in: videoSpeedAndQualityView)
        
        if let contentView = allEpisodsView.subviews.first {
            if contentView.frame.contains(location) {
                return false
            }
        }
        
        if let contentView = videoSpeedAndQualityView.subviews.first {
            if contentView.frame.contains(videoLocation) {
                return false
            }
        }
        
        return true
    }
}

// MARK: - Button Actions Extension
extension StoriesPlayingCell {
    
    @IBAction func allEpisodsViewButtonAction(_ sender: UIButton) {
        hideAllPopups()
        showAllEpisodsPopup()
    }
    
    @IBAction func shareButtonAction(_ sender: UIButton) {
        shareHandler?()
    }
    
    @IBAction func saveButtonAction(_ sender: UIButton) {
        saveHandler?()
    }
    
    @IBAction func playSpeedExpandButtonAction(_ sender: UIButton) {
        isPlaySpeedExpanded = !isPlaySpeedExpanded
        
        // Animate the height change
        UIView.animate(withDuration: 0.3) {
            if self.isPlaySpeedExpanded {
                // Expand: show all 4 buttons
                self.oneXSpeedButton.isHidden = false
                self.onePointFiveXSpeedButton.isHidden = false
                self.twoXSpeedButton.isHidden = false
                self.playSpeedOptionsHeightConstant.constant = 34 * 4 // 136
            } else {
                // Collapse: show only 0.75X button
                self.oneXSpeedButton.isHidden = true
                self.onePointFiveXSpeedButton.isHidden = true
                self.twoXSpeedButton.isHidden = true
                self.playSpeedOptionsHeightConstant.constant = 34
            }
            
            // Update layout
            self.videoSpeedAndQualityView.layoutIfNeeded()
            self.updateScrollViewContentSize()
        }
        
        // Update button colors
        updateSpeedButtons()
    }

    @IBAction func displayVideoQualityExpandButtonAction(_ sender: UIButton) {
        isVideoQualityExpanded = !isVideoQualityExpanded
        
        // Animate the height change
        UIView.animate(withDuration: 0.3) {
            if self.isVideoQualityExpanded {
                // Expand: show 480P and 720P buttons
                self.fourHundredEighyPVideoQualityButton.isHidden = false
                self.seventHundredTwentyPVideoQualityButton.isHidden = false
                self.videoQualityHeightConstant.constant = 34 * 3 // 102
            } else {
                // Collapse: show only 240P button
                self.fourHundredEighyPVideoQualityButton.isHidden = true
                self.seventHundredTwentyPVideoQualityButton.isHidden = true
                self.videoQualityHeightConstant.constant = 34
            }
            
            // Update layout
            self.videoSpeedAndQualityView.layoutIfNeeded()
            self.updateScrollViewContentSize()
        }
        
        // Update button colors
        updateQualityButtons()
    }
    
    @IBAction func moreButtonAction(_ sender: UIButton) {
        hideAllPopups()
        showVideoSpeedPopup()
    }
    private func updateScrollViewContentSize() {
        // Calculate the total height needed
        let speedHeight = playSpeedOptionsHeightConstant.constant
        let qualityHeight = videoQualityHeightConstant.constant
        
        // Add spacing between sections and padding
        let totalHeight = speedHeight + qualityHeight + 40 // 40 for padding
        
        // Update scroll view content size
        scrollViewDisplayVideoQualityWithSpeed.contentSize = CGSize(
            width: scrollViewDisplayVideoQualityWithSpeed.frame.width,
            height: totalHeight
        )
    }
}
extension StoriesPlayingCell {
    private func prepareBottomSheetView(_ view: UIView, height: CGFloat) -> UIView {
        view.isHidden = false
        view.removeFromSuperview()
        view.frame = CGRect(
            x: 0,
            y: 0,
            width: UIScreen.main.bounds.width,
            height: height
        )
        return view
    }
}
