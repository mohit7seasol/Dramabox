//
//  StoriesPlayingCell.swift
//  DramaBox
//
//  Created by DREAMWORLD on 08/12/25.
//

import UIKit
import AVFoundation
import SDWebImage

class StoriesPlayingCell: UITableViewCell {

    @IBOutlet weak var appTitleHeaderView: UIView!
    @IBOutlet weak var navigationTitleView: UIView!
    @IBOutlet weak var appTitleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var navigationTitleLabel: UILabel!
    @IBOutlet weak var moreButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var userProfieInfoView: UIView!
    @IBOutlet weak var userProfileImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var storieDetailsLabel: UILabel!
    @IBOutlet weak var enjoyFullStoriesView: UIView!
    @IBOutlet weak var enjoyFullStoriesLabel: UILabel!
    @IBOutlet weak var enjoyFullStoriesButton: UIButton!
    @IBOutlet weak var videoSliderView: UIView!
    @IBOutlet weak var videoSlider: UISlider!
    @IBOutlet weak var startDurationLabel: UILabel!
    @IBOutlet weak var endDurationLabel: UILabel!
    @IBOutlet weak var allEpisodsButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var storiesThumbImageView: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var storieDetailsLabelHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var videoSliderViewHeightConstant: NSLayoutConstraint!
    @IBOutlet weak var fullStoryViewHeightConstant: NSLayoutConstraint!
    
    
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    private var isVideoPlaying = false
    private var currentDrama: DramaItem?
    private var currentEpisode: EpisodeItem?
    private var isStoryDetailsExpanded = false
    
    // Handlers
    var enjoyFullStoriesHandler: (() -> Void)?
    var storyDetailsTappedHandler: (() -> Void)?
    var shareHandler: (() -> Void)?
    var saveHandler: (() -> Void)?
    var backButtonHandler: (() -> Void)?
    var moreButtonHandler: (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setCellUI()
        setupGestureRecognizers()
        setupControls()
        setupStoryDetailsLabel()
        setupButtonActions()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        playerLayer?.frame = mainView.bounds
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetVideo()
        currentDrama = nil
        currentEpisode = nil
        hideLoading()
        isStoryDetailsExpanded = false
        updateStoryDetailsLabel()
    }
    
    func setCellUI() {
        mainView.backgroundColor = .black
        
        // Setup user profile image
        userProfileImageView.layer.cornerRadius = userProfileImageView.frame.width / 2
        userProfileImageView.clipsToBounds = true
        userProfileImageView.image = UIImage(named: "user_placeholder")
        
        // Setup loading indicator
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.color = .white
        loadingIndicator.style = .large
        
        // Setup play/pause button
        playButton.isHidden = true
        playButton.tintColor = .white
        playButton.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        playButton.layer.cornerRadius = 30
        playButton.layer.masksToBounds = true
        playButton.setImage(UIImage(named: "play"), for: .normal)
        
        // Setup story details label
        storieDetailsLabel.textColor = .white
        storieDetailsLabel.numberOfLines = 2 // Initially 2 lines
        storieDetailsLabel.isUserInteractionEnabled = true
        
        // Setup slider
        setupSlider()
    }
    
    private func setupButtonActions() {
        // Setup button actions
        enjoyFullStoriesButton.addTarget(self, action: #selector(enjoyFullStoriesTapped), for: .touchUpInside)
        shareButton.addTarget(self, action: #selector(shareButtonTapped), for: .touchUpInside)
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
        playButton.addTarget(self, action: #selector(togglePlayPause), for: .touchUpInside)
    }
    
    private func setupSlider() {
        videoSlider.minimumTrackTintColor = .white
        videoSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.3)
        videoSlider.minimumValue = 0
        videoSlider.maximumValue = 1
        
        let thumbSize: CGFloat = 20
        let thumbImage = createThumbImage(size: thumbSize, color: .white)
        videoSlider.setThumbImage(thumbImage, for: .normal)
        videoSlider.setThumbImage(thumbImage, for: .highlighted)
        
        videoSlider.addTarget(self, action: #selector(sliderValueChanged(_:)), for: .valueChanged)
    }
    
    private func createThumbImage(size: CGFloat, color: UIColor) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: size, height: size))
        return renderer.image { context in
            color.setFill()
            context.cgContext.fillEllipse(in: CGRect(x: 0, y: 0, width: size, height: size))
            UIColor.black.withAlphaComponent(0.3).setFill()
            let innerSize = size - 6
            context.cgContext.fillEllipse(in: CGRect(x: 3, y: 3, width: innerSize, height: innerSize))
        }
    }
    
    private func setupControls() {
        playButton.addTarget(self, action: #selector(togglePlayPause), for: .touchUpInside)
    }
    
    private func setupGestureRecognizers() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        mainView.addGestureRecognizer(tapGesture)
        mainView.isUserInteractionEnabled = true
        
        // Tap gesture for story details label
        let detailsTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleStoryDetailsTap))
        storieDetailsLabel.addGestureRecognizer(detailsTapGesture)
    }
    
    private func setupStoryDetailsLabel() {
        updateStoryDetailsLabel()
    }
    
    private func updateStoryDetailsLabel() {
        guard let text = storieDetailsLabel.text else {
            storieDetailsLabelHeightConstraint.constant = 0
            return
        }
        
        if isStoryDetailsExpanded {
            // Expanded state
            storieDetailsLabel.numberOfLines = 0
            storieDetailsLabelHeightConstraint.constant = calculateLabelHeight(for: text, width: storieDetailsLabel.frame.width)
        } else {
            // Collapsed state
            storieDetailsLabel.numberOfLines = 2
            storieDetailsLabelHeightConstraint.constant = calculateLabelHeight(for: text, width: storieDetailsLabel.frame.width, maxLines: 2)
        }
    }
    
    private func calculateLabelHeight(for text: String, width: CGFloat, maxLines: Int = 0) -> CGFloat {
        let label = UILabel()
        label.numberOfLines = maxLines
        label.font = storieDetailsLabel.font
        label.text = text
        
        let maxSize = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let requiredSize = label.sizeThatFits(maxSize)
        return requiredSize.height
    }
    
    // MARK: - Configuration Methods
    
    func configureWithDrama(drama: DramaItem, viewType: StoriesPlayingViewTypes) {
        currentDrama = drama
        
        // Update UI based on view type
        updateUIForViewType(viewType)
        
        // Set data for viewType == isOpenStories
        if viewType == .isOpenStories {
            // Fill data for appTitleHeaderView
            appTitleLabel.text = "Stories"
            
            // Fill user info
            userNameLabel.text = drama.dramaName ?? "Unknown"
            
            // Fill story details
            if let dDesc = drama.dDesc, !dDesc.isEmpty {
                storieDetailsLabel.text = dDesc
            } else {
                storieDetailsLabel.text = drama.dramaName ?? "No description available"
            }
            
            // Fill thumbnail image
            if let imageUrl = drama.imageUrl, let url = URL(string: imageUrl) {
                storiesThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "video_placeholder"))
                userProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
            }
        }
        
        // Reset story details to collapsed state
        isStoryDetailsExpanded = false
        updateStoryDetailsLabel()
        
        // Setup video player with epi_url
        setupVideoPlayerWithDrama(drama: drama)
    }
    
    func configureWithEpisode(episode: EpisodeItem, viewType: StoriesPlayingViewTypes, dramaName: String? = nil) {
        currentEpisode = episode
        
        // Update UI based on view type
        updateUIForViewType(viewType)
        
        // Set data for viewType == isOpenAllStoriesEpisods
        if viewType == .isOpenAllStoriesEpisods {
            // Set navigation title
            navigationTitleLabel.text = dramaName ?? episode.dName
            
            // Fill user info
            userNameLabel.text = episode.dName
            
            // Fill thumbnail image
            if !episode.thumbnails.isEmpty, let url = URL(string: episode.thumbnails) {
                storiesThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "video_placeholder"))
            }
            
            // Fill user profile image
            if !episode.dImage.isEmpty, let url = URL(string: episode.dImage) {
                userProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
            }
            
            // Reset duration labels (will be updated when video loads)
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
        }
        
        // Setup video player with episode video
        setupVideoPlayerWithEpisode(episode: episode)
    }
    
    private func updateUIForViewType(_ viewType: StoriesPlayingViewTypes) {
        switch viewType {
        case .isOpenStories:
            // Show appTitleHeaderView and hide navigationTitleView
            appTitleHeaderView.isHidden = false
            navigationTitleView.isHidden = true
            
            // Show userProfieInfoView, storieDetailsLabel, enjoyFullStoriesView
            // Hide videoSliderView
            userProfieInfoView.isHidden = false
            storieDetailsLabel.isHidden = false
            enjoyFullStoriesView.isHidden = false
            videoSliderView.isHidden = true
            
            videoSliderViewHeightConstant.constant = 0
            storieDetailsLabelHeightConstraint.constant = 34
        case .isOpenAllStoriesEpisods:
            // Hide appTitleHeaderView and show navigationTitleView
            appTitleHeaderView.isHidden = true
            navigationTitleView.isHidden = false
            
            // Show userProfieInfoView, videoSliderView
            // Hide storieDetailsLabel, enjoyFullStoriesView
            userProfieInfoView.isHidden = false
            videoSliderView.isHidden = false
            storieDetailsLabel.isHidden = true
            enjoyFullStoriesView.isHidden = true
            
            fullStoryViewHeightConstant.constant = 0
            storieDetailsLabelHeightConstraint.constant = 0
            videoSliderViewHeightConstant.constant = 70
        }
    }
    
    private func setupVideoPlayerWithDrama(drama: DramaItem) {
        resetVideo()
        
        // Get video URL from drama (epi_url)
        guard let videoUrlString = drama.epiUrl, !videoUrlString.isEmpty,
              let url = URL(string: videoUrlString) else {
            // If no video URL, just show image
            storiesThumbImageView.isHidden = false
            playButton.isHidden = true
            return
        }
        
        setupPlayer(with: url)
    }
    
    private func setupVideoPlayerWithEpisode(episode: EpisodeItem) {
        resetVideo()
        
        // Get video URL (prefer no subtitle version if available)
        let videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
        
        guard !videoUrlString.isEmpty, let url = URL(string: videoUrlString) else {
            storiesThumbImageView.isHidden = false
            playButton.isHidden = true
            return
        }
        
        setupPlayer(with: url)
    }
    
    private func setupPlayer(with url: URL) {
        showLoading()
        
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = mainView.bounds
        playerLayer?.videoGravity = .resizeAspectFill
        
        if let layer = playerLayer {
            mainView.layer.insertSublayer(layer, below: storiesThumbImageView.layer)
        }
        
        // Add observer for video end
        NotificationCenter.default.addObserver(self,
                                             selector: #selector(videoDidEnd),
                                             name: .AVPlayerItemDidPlayToEndTime,
                                             object: playerItem)
        
        // Add observers for player status
        playerItem.addObserver(self, forKeyPath: "status", options: [.new], context: nil)
        playerItem.addObserver(self, forKeyPath: "duration", options: [.new], context: nil)
        
        // Add time observer for slider updates and duration labels
        player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.1, preferredTimescale: CMTimeScale(NSEC_PER_SEC)), queue: .main) { [weak self] time in
            self?.updateSliderPosition()
            self?.updateDurationLabels()
        }
    }
    
    private func updateSliderPosition() {
        guard let player = player,
              let playerItem = player.currentItem else {
            videoSlider.value = 0
            return
        }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else {
            videoSlider.value = 0
            return
        }
        
        let currentTime = CMTimeGetSeconds(player.currentTime())
        let totalDuration = CMTimeGetSeconds(duration)
        
        videoSlider.value = Float(currentTime / totalDuration)
    }
    
    private func updateDurationLabels() {
        guard let player = player,
              let playerItem = player.currentItem else {
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
            return
        }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else {
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
            return
        }
        
        // Update current time
        let currentTime = CMTimeGetSeconds(player.currentTime())
        startDurationLabel.text = formatTime(currentTime)
        
        // Update total duration
        let totalDuration = CMTimeGetSeconds(duration)
        endDurationLabel.text = formatTime(totalDuration)
    }
    
    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite && !seconds.isNaN else {
            return "0:00"
        }
        
        let minutes = Int(seconds) / 60
        let remainingSeconds = Int(seconds) % 60
        return String(format: "%d:%02d", minutes, remainingSeconds)
    }
    
    func playVideo() {
        guard let player = player else { return }
        
        if !isVideoPlaying {
            storiesThumbImageView.isHidden = true
            player.play()
            isVideoPlaying = true
            playButton.setImage(UIImage(named: "pause"), for: .normal)
            playButton.isHidden = false
        }
    }
    
    func pauseVideo() {
        guard let player = player, isVideoPlaying else { return }
        
        player.pause()
        isVideoPlaying = false
        playButton.setImage(UIImage(named: "play"), for: .normal)
        playButton.isHidden = false
    }
    
    private func resetVideo() {
        pauseVideo()
        
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: nil)
        
        if let playerItem = player?.currentItem {
            playerItem.removeObserver(self, forKeyPath: "status")
            playerItem.removeObserver(self, forKeyPath: "duration")
        }
        
        playerLayer?.removeFromSuperlayer()
        player = nil
        playerLayer = nil
        storiesThumbImageView.isHidden = false
        videoSlider.value = 0
        startDurationLabel.text = "0:00"
        endDurationLabel.text = "0:00"
    }
    
    // MARK: - Loading
    
    private func showLoading() {
        loadingIndicator.startAnimating()
        loadingIndicator.isHidden = false
        playButton.isHidden = true
    }
    
    private func hideLoading() {
        loadingIndicator.stopAnimating()
        loadingIndicator.isHidden = true
    }
    
    // MARK: - Button Actions
    
    @objc private func togglePlayPause() {
        if isVideoPlaying {
            pauseVideo()
        } else {
            playVideo()
        }
    }
    
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        togglePlayPause()
    }
    
    @objc private func handleStoryDetailsTap() {
        isStoryDetailsExpanded = !isStoryDetailsExpanded
        updateStoryDetailsLabel()
        
        // Notify view controller to update cell height
        storyDetailsTappedHandler?()
    }
    
    @objc private func enjoyFullStoriesTapped() {
        enjoyFullStoriesHandler?()
    }
    
    @objc private func shareButtonTapped() {
        shareHandler?()
    }
    
    @objc private func saveButtonTapped() {
        saveHandler?()
    }
    
    @objc private func backButtonTapped() {
        backButtonHandler?()
    }
    
    @objc private func moreButtonTapped() {
        moreButtonHandler?()
    }
    
    @objc private func sliderValueChanged(_ sender: UISlider) {
        guard let player = player,
              let playerItem = player.currentItem else { return }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else { return }
        
        let totalDuration = CMTimeGetSeconds(duration)
        let targetTime = Double(sender.value) * totalDuration
        let seekTime = CMTime(seconds: targetTime, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        
        player.seek(to: seekTime, toleranceBefore: .zero, toleranceAfter: .zero)
        
        // Update current time label when slider changes
        startDurationLabel.text = formatTime(targetTime)
    }
    
    @objc private func videoDidEnd() {
        // For stories, you might want to auto-advance to next story
        // For episodes, loop or go to next episode
        player?.seek(to: .zero)
        player?.play()
    }
    
    // MARK: - KVO
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let playerItem = object as? AVPlayerItem else { return }
        
        if keyPath == "status" {
            switch playerItem.status {
            case .readyToPlay:
                hideLoading()
                playButton.isHidden = false
                // Update duration labels when video is ready
                updateDurationLabels()
            case .failed:
                hideLoading()
                storiesThumbImageView.isHidden = false
                playButton.isHidden = true
            default:
                break
            }
        } else if keyPath == "duration" {
            // Update end duration label when duration is known
            updateDurationLabels()
        }
    }
    
    deinit {
        resetVideo()
    }
}
