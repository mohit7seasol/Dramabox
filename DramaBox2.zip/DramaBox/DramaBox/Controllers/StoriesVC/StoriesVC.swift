//
//  StoriesVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import UIKit
import SVProgressHUD

enum StoriesPlayingViewTypes {
    case isOpenStories
    case isOpenAllStoriesEpisods
}
class StoriesVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var storiesPlayingViewType: StoriesPlayingViewTypes = .isOpenStories
    var allDramaStories: [DramaItem] = []
    
    // Properties for pagination
    private var currentPage = 1
    private var isLoading = false
    private var hasMoreData = true
    private var currentPlayingIndex: Int = -1
    private var initialLoadComplete = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        
        // Show loading view before fetching
        showInitialLoading()
        fetchAllStories(page: 1)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateNavigationBar()
    }
    private func updateNavigationBar() {
        // Always hide navigation bar for stories
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    private func showInitialLoading() {
        SVProgressHUD.show()
    }
    
    private func hideInitialLoading() {
        SVProgressHUD.dismiss()
    }
    func setUpUI() {
        settable()
    }
    func settable() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(["StoriesPlayingCell"])
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = .black
        self.tableView.isPagingEnabled = true
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.contentInsetAdjustmentBehavior = .never
        
        // Initially hide table view until data loads
        tableView.isHidden = true
    }
    private func playVideoForVisibleCell() {
        guard let indexPath = getCenterCellIndexPath() else { return }
        
        // If we're already playing this cell, do nothing
        if currentPlayingIndex == indexPath.row { return }
        
        // Pause previously playing video
        if currentPlayingIndex >= 0,
           let previousCell = tableView.cellForRow(at: IndexPath(row: currentPlayingIndex, section: 0)) as? StoriesPlayingCell {
            previousCell.pauseVideo()
        }
        
        // Play new video
        if let currentCell = tableView.cellForRow(at: indexPath) as? StoriesPlayingCell {
            currentCell.playVideo()
            currentPlayingIndex = indexPath.row
            
            // Load more data when near the end
            if indexPath.row >= allDramaStories.count - 3 && !isLoading {
                loadMoreData()
            }
        }
    }
    
    private func getCenterCellIndexPath() -> IndexPath? {
        let center = view.convert(tableView.center, to: tableView)
        return tableView.indexPathForRow(at: center)
    }
    
    private func loadMoreData() {
        guard !isLoading && hasMoreData else { return }
        fetchAllStories(page: currentPage + 1, isLoadMore: true)
    }
    
    private func pauseAllVideos() {
        for cell in tableView.visibleCells {
            if let storiesCell = cell as? StoriesPlayingCell {
                storiesCell.pauseVideo()
            }
        }
        currentPlayingIndex = -1
    }
    
    func navigateToViewAllEpisodes(for dramaId: String, dramaName: String?) {
        // Navigate to ViewAllEpisodsStoriesVC
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let viewAllEpisodesVC = storyboard.instantiateViewController(withIdentifier: "ViewAllEpisodsStoriesVC") as? ViewAllEpisodsStoriesVC {
            viewAllEpisodesVC.dramaId = dramaId
            viewAllEpisodesVC.dramaName = dramaName
            viewAllEpisodesVC.storiesPlayingViewType = .isOpenAllStoriesEpisods
            viewAllEpisodesVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(viewAllEpisodesVC, animated: true)
//            viewAllEpisodesVC.modalPresentationStyle = .fullScreen
//            present(viewAllEpisodesVC, animated: true, completion: nil)
        }
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension StoriesVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allDramaStories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StoriesPlayingCell",
                                                 for: indexPath) as? StoriesPlayingCell ?? StoriesPlayingCell()
        cell.selectionStyle = .none
        
        if indexPath.row < allDramaStories.count {
            let drama = allDramaStories[indexPath.row]
            
            // Configure cell with drama data for isOpenStories view
            cell.configureWithDrama(drama: drama, viewType: .isOpenStories)
            
            // Handle enjoy full stories button tap
            cell.enjoyFullStoriesHandler = { [weak self] in
                guard let self = self, let dramaId = drama.id else { return }
                self.navigateToViewAllEpisodes(for: dramaId, dramaName: drama.dramaName)
            }
            
            // Handle story details expansion
            cell.storyDetailsTappedHandler = { [weak self] in
                tableView.beginUpdates()
                tableView.endUpdates()
            }
            
            // Handle share button
            cell.shareHandler = { [weak self] in
//                self?.shareDrama(drama)
            }
            
            // Handle save button
            cell.saveHandler = { [weak self] in
//                self?.saveDrama(drama)
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.height
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let storiesCell = cell as? StoriesPlayingCell {
            storiesCell.pauseVideo()
            if currentPlayingIndex == indexPath.row {
                currentPlayingIndex = -1
            }
        }
    }
}
// MARK: - Scroll autoplay
extension StoriesVC: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        playVideoForVisibleCell()
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            playVideoForVisibleCell()
        }
    }
}
// MARK: - Api's calling
extension StoriesVC {
    func fetchAllStories(page: Int, isLoadMore: Bool = false) {
        guard !isLoading, (isLoadMore ? hasMoreData : true) else { return }
        
        isLoading = true
        if !isLoadMore {
            SVProgressHUD.show()
        }
        
        NetworkManager.shared.fetchDramas(from: self, page: page) { [weak self] result in
            guard let self = self else { return }
            
            self.isLoading = false
            if !isLoadMore {
                SVProgressHUD.dismiss()
            }
            
            switch result {
            case .success(let response):
                // Process sections based on heading
                var newDramas: [DramaItem] = []
                for section in response.data.data {
                    // Filter items that have drama_name and image_url
                    let validItems = section.list.filter { item in
                        let hasName = item.dramaName != nil && !item.dramaName!.isEmpty
                        let hasImage = item.imageUrl != nil && !item.imageUrl!.isEmpty
                        return hasName && hasImage
                    }
                    newDramas.append(contentsOf: validItems)
                }
                
                if isLoadMore {
                    self.allDramaStories.append(contentsOf: newDramas)
                } else {
                    self.allDramaStories = newDramas
                    
                    // Hide initial loading and show table view
                    DispatchQueue.main.async {
                        self.hideInitialLoading()
                        self.tableView.isHidden = false
                        self.initialLoadComplete = true
                    }
                }
                
                // Update pagination state
                self.hasMoreData = !newDramas.isEmpty
                if self.hasMoreData {
                    self.currentPage = page
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    
                    // Auto-play first video if initial load
                    if !isLoadMore && !self.allDramaStories.isEmpty && self.initialLoadComplete {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            self.playVideoForVisibleCell()
                        }
                    }
                }
                
            case .failure(let error):
                print("Error fetching dramas: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.hideInitialLoading()
                    self.tableView.isHidden = false
                    
                    if self.allDramaStories.isEmpty {
                        self.showEmptyState()
                    }
                }
            }
        }
    }
    
    private func showEmptyState() {
        let emptyLabel = UILabel(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: tableView.bounds.height))
        emptyLabel.text = "No stories available"
        emptyLabel.textColor = .white
        emptyLabel.textAlignment = .center
        emptyLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        
        tableView.backgroundView = emptyLabel
    }
}
