//
//  StoriesPlayingCell.swift
//  DramaBox
//
//  Created by DREAMWORLD on 08/12/25.
//

import UIKit
import AVFoundation
import SDWebImage
import SwiftPopup

class StoriesPlayingCell: UITableViewCell {
    
    // MARK: - Existing Outlets (removed popup view outlets)
    @IBOutlet weak var appTitleHeaderView: UIView!
    @IBOutlet weak var navigationTitleView: UIView!
    @IBOutlet weak var appTitleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var navigationTitleLabel: UILabel!
    @IBOutlet weak var moreButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var userProfieInfoView: UIView!
    @IBOutlet weak var userProfileImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var storieDetailsLabel: UILabel!
    @IBOutlet weak var enjoyFullStoriesView: UIView!
    @IBOutlet weak var enjoyFullStoriesLabel: UILabel!
    @IBOutlet weak var enjoyFullStoriesButton: UIButton!
    @IBOutlet weak var videoSliderView: UIView!
    @IBOutlet weak var videoSlider: UISlider!
    @IBOutlet weak var startDurationLabel: UILabel!
    @IBOutlet weak var endDurationLabel: UILabel!
    @IBOutlet weak var allEpisodsButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var storiesThumbImageView: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var storieDetailsLabelHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var videoSliderViewHeightConstant: NSLayoutConstraint!
    @IBOutlet weak var fullStoryViewHeightConstant: NSLayoutConstraint!
    
    // MARK: - Existing Properties
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    private var isVideoPlaying = false
    private var currentDrama: DramaItem?
    var currentEpisode: EpisodeItem?
    private var isStoryDetailsExpanded = false
    
    // New properties
    private var allEpisodes: [EpisodeItem] = []
    private var selectedEpisodeIndex: Int = 0
    private var isPlaySpeedExpanded: Bool = false
    private var isVideoQualityExpanded: Bool = false
    private var selectedSpeedIndex: Int = 0 // 0: 0.75X, 1: 1X, 2: 1.5X, 3: 2X
    private var selectedQualityIndex: Int = 0 // 0: 240P, 1: 480P, 2: 720P
    private var isSubscribed: Bool = false // Will be updated from Subscribe.get()
    
    // Handlers
    var enjoyFullStoriesHandler: (() -> Void)?
    var storyDetailsTappedHandler: (() -> Void)?
    var shareHandler: (() -> Void)?
    var saveHandler: (() -> Void)?
    var backButtonHandler: (() -> Void)?
    var moreButtonHandler: (() -> Void)?
    var episodeSelectedHandler: ((EpisodeItem) -> Void)?
    var allEpisodesForDrama: [EpisodeItem] = []
    var storiesPlayingViewType: StoriesPlayingViewTypes = .isOpenStories
    
    // property for video progress tracking
    private var currentVideoProgress: Double = 0.0
    
    // Add these properties for auto-hide controls
    private var controlsHideTimer: Timer?
    private let controlsHideDelay: TimeInterval = 3.0 // Hide after 3 seconds
    private var isControlsVisible: Bool = false
    
    private var isPlayerReady = false
    private var shouldAutoPlay = false
    
    // MARK: - SwiftPopup instances
    private var episodesPopup: EpisodesViewBottomPopUp?
    private var speedPopup: SpeedSetBottomPopUp?
    private var timeObserverToken: Any?
    
    // MARK: - Lifecycle Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setCellUI()
        setupGestureRecognizers()
        setupControls()
        setupStoryDetailsLabel()
        setupButtonActions()
        
        // Update subscription status
        self.isSubscribed = Subscribe.get()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // Ensure mainView has proper bounds
        if mainView.bounds.size == .zero {
            mainView.frame = contentView.bounds
        }
        
        playerLayer?.frame = mainView.bounds
        contentView.bringSubviewToFront(playButton)
        
        // Force layout update for view type specific elements
        if storiesPlayingViewType == .isOpenAllStoriesEpisods {
            videoSliderView.isHidden = false
            videoSliderViewHeightConstant.constant = 70
            layoutIfNeeded()
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        print("prepareForReuse() called - storiesPlayingViewType: \(storiesPlayingViewType)")
        
        forceHideAllControls()
        resetVideo()
        
        currentDrama = nil
        currentEpisode = nil
        hideLoading()
        isStoryDetailsExpanded = false
        updateStoryDetailsLabel()
        currentVideoProgress = 0.0
        
        isPlayerReady = false
        shouldAutoPlay = false
        
        playButton.setImage(UIImage(named: "play"), for: .normal)
        isVideoPlaying = false
        
        // Reset view type specific UI
        updateUIForViewType(storiesPlayingViewType)
        
        print("prepareForReuse() complete")
    }
    
    // MARK: - UI Setup
    
    func setCellUI() {
        mainView.backgroundColor = .black
        self.appTitleLabel.text = "DramaBox".localized(LocalizationService.shared.language)
        
        userProfileImageView.layer.cornerRadius = userProfileImageView.frame.width / 2
        userProfileImageView.clipsToBounds = true
        userProfileImageView.image = UIImage(named: "user_placeholder")
        
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.color = .white
        loadingIndicator.style = .large
        
        playButton.isHidden = true
        playButton.tintColor = .white
        playButton.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        playButton.layer.cornerRadius = 30
        playButton.layer.masksToBounds = true
        playButton.setImage(UIImage(named: "play"), for: .normal)
        playButton.isUserInteractionEnabled = true
        
        storieDetailsLabel.textColor = .white
        storieDetailsLabel.numberOfLines = 2
        storieDetailsLabel.isUserInteractionEnabled = true
        
        setupSlider()
        updateControlsVisibilityForInitialState()
    }
    
    private func updateControlsVisibilityForInitialState() {
        // Ensure play button is visible when video is not playing
        playButton.isHidden = false
        
        if storiesPlayingViewType == .isOpenStories {
            videoSliderView.isHidden = true
        } else {
            videoSliderView.isHidden = false
        }
    }
    
    // MARK: - Controls Management
    
    private func showControls() {
        print("showControls() called")
        
        playButton.isHidden = false
        
        if storiesPlayingViewType == .isOpenAllStoriesEpisods {
            videoSliderView.isHidden = false
        }
        
        isControlsVisible = true
    }
    
    private func hideControls() {
        print("hideControls() called - isVideoPlaying: \(isVideoPlaying)")
        
        if isVideoPlaying {
            playButton.isHidden = true
            
            if storiesPlayingViewType == .isOpenAllStoriesEpisods {
                videoSliderView.isHidden = true
            }
            
            isControlsVisible = false
        } else {
            print("Video is paused, keeping controls visible")
        }
        
        controlsHideTimer?.invalidate()
        controlsHideTimer = nil
    }
    
    private func toggleControls() {
        if isControlsVisible {
            hideControls()
        } else {
            showControls()
            startControlsHideTimer()
        }
    }
    
    private func startControlsHideTimer() {
        print("startControlsHideTimer() called - isVideoPlaying: \(isVideoPlaying)")
        
        guard isVideoPlaying else {
            print("Video is not playing, not starting hide timer")
            return
        }
        
        controlsHideTimer?.invalidate()
        
        controlsHideTimer = Timer.scheduledTimer(withTimeInterval: controlsHideDelay, repeats: false) { [weak self] _ in
            print("Auto-hide timer fired")
            self?.hideControls()
        }
    }
    
    private func resetControlsHideTimer() {
        print("resetControlsHideTimer() called - isVideoPlaying: \(isVideoPlaying)")
        
        if isVideoPlaying && isControlsVisible {
            startControlsHideTimer()
        }
    }
    
    private func forceHideAllControls() {
        print("forceHideAllControls() called")
        
        hideControls()
        controlsHideTimer?.invalidate()
        controlsHideTimer = nil
    }
    
    // MARK: - Video Playback Methods
    
    func playVideo() {
        guard let player = player else {
            print("Cannot play: player is nil")
            return
        }
        
        if !isVideoPlaying {
            if isPlayerReady {
                print("Player is ready, starting playback")
                storiesThumbImageView.isHidden = true
                player.play()
                isVideoPlaying = true
                playButton.setImage(UIImage(named: "pause"), for: .normal)
                
                // FIX: Ensure slider is visible and starts tracking when playing
                if storiesPlayingViewType == .isOpenAllStoriesEpisods {
                    videoSliderView.isHidden = false
                }
                
                showControls()
                startControlsHideTimer()
            } else {
                print("Player not ready yet, marking for auto-play")
                shouldAutoPlay = true
                storiesThumbImageView.isHidden = false
                playButton.setImage(UIImage(named: "play"), for: .normal)
                showControls()
            }
        }
    }
    private func startSliderUpdates() {
        guard storiesPlayingViewType == .isOpenAllStoriesEpisods else { return }
        
        // Remove existing observer if any
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
        }
        
        // Add new time observer
        timeObserverToken = player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.1, preferredTimescale: CMTimeScale(NSEC_PER_SEC)), queue: .main) { [weak self] time in
            self?.updateSliderPosition()
            self?.updateDurationLabels()
        }
    }
    
    func pauseVideo() {
        guard let player = player else {
            print("Cannot pause: player is nil")
            return
        }
        
        if isVideoPlaying {
            player.pause()
            isVideoPlaying = false
            shouldAutoPlay = false
            playButton.setImage(UIImage(named: "play"), for: .normal)
            
            showControlsPermanently()
        }
    }
    
    func playVideoIfReady() {
        print("playVideoIfReady() called - isPlayerReady: \(isPlayerReady), isVideoPlaying: \(isVideoPlaying)")
        
        if isPlayerReady && !isVideoPlaying {
            playVideo()
        } else if !isPlayerReady {
            shouldAutoPlay = true
            showControls()
        }
    }
    
    private func showControlsPermanently() {
        print("showControlsPermanently() called")
        
        controlsHideTimer?.invalidate()
        controlsHideTimer = nil
        
        playButton.isHidden = false
        
        if storiesPlayingViewType == .isOpenAllStoriesEpisods {
            videoSliderView.isHidden = false
        }
        
        isControlsVisible = true
    }
    
    private func resetVideo() {
        print("resetVideo() called")
        pauseVideo()
        
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: nil)
        
        // Remove time observer
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
            timeObserverToken = nil
            print("Removed time observer")
        }
        
        if let playerItem = player?.currentItem {
            print("Removing observers from playerItem")
            playerItem.removeObserver(self, forKeyPath: "status")
            playerItem.removeObserver(self, forKeyPath: "duration")
        }
        
        playerLayer?.removeFromSuperlayer()
        print("Player layer removed from superlayer")
        
        player = nil
        playerLayer = nil
        storiesThumbImageView.isHidden = false
        
        // FIX: Reset slider values to 0
        videoSlider.value = 0
        startDurationLabel.text = "0:00"
        endDurationLabel.text = "0:00"
        currentVideoProgress = 0.0
        
        hideControls()
        playButton.setImage(UIImage(named: "play"), for: .normal)
        isVideoPlaying = false
        
        // Reset slider visibility for the view type
        if storiesPlayingViewType == .isOpenAllStoriesEpisods {
            videoSliderView.isHidden = false
        }
        
        print("resetVideo() complete - isVideoPlaying: \(isVideoPlaying)")
    }
    
    // MARK: - Configuration Methods
    
    func configureWithDrama(drama: DramaItem, viewType: StoriesPlayingViewTypes, allEpisodes: [EpisodeItem] = []) {
        currentDrama = drama
        self.allEpisodesForDrama = allEpisodes
        
        updateUIForViewType(viewType)
        self.storiesPlayingViewType = viewType
        
        if viewType == .isOpenStories {
            userNameLabel.text = drama.dramaName ?? "Unknown"
            
            if let dDesc = drama.dDesc, !dDesc.isEmpty {
                storieDetailsLabel.text = dDesc
            } else {
                storieDetailsLabel.text = drama.dramaName ?? "No description available"
            }
            
            if let imageUrl = drama.imageUrl, let url = URL(string: imageUrl) {
                storiesThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "video_placeholder"))
                userProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
            }
            
            self.allEpisodes = allEpisodes
        }
        
        isStoryDetailsExpanded = false
        updateStoryDetailsLabel()
        
        playButton.setImage(UIImage(named: "play"), for: .normal)
        isVideoPlaying = false
        
        hideControls()
        
        setupVideoPlayerWithDrama(drama: drama)
    }
    
    func configureWithEpisode(episode: EpisodeItem, viewType: StoriesPlayingViewTypes, dramaName: String? = nil, allEpisodes: [EpisodeItem] = [], currentIndex: Int = 0) {
        currentEpisode = episode
        self.allEpisodes = allEpisodes
        self.selectedEpisodeIndex = currentIndex
        self.storiesPlayingViewType = viewType
        
        self.isSubscribed = Subscribe.get()
        
        // Update UI BEFORE setting up video player
        updateUIForViewType(viewType)
        
        // Force layout update immediately
        self.setNeedsLayout()
        self.layoutIfNeeded()
        
        if viewType == .isOpenAllStoriesEpisods {
            navigationTitleLabel.text = dramaName ?? episode.dName
            userNameLabel.text = episode.dName
            
            if !episode.thumbnails.isEmpty, let url = URL(string: episode.thumbnails) {
                storiesThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "video_placeholder"))
            }
            
            if !episode.dImage.isEmpty, let url = URL(string: episode.dImage) {
                userProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
            }
            
            let isSaved = LocalStorageManager.shared.isEpisodeSaved(episodeId: episode.epiId)
            updateSaveButtonState(isSaved: isSaved)
        } else {
            saveButton.isHidden = true
        }
        
        playButton.setImage(UIImage(named: "play"), for: .normal)
        isVideoPlaying = false
        
        hideControls()
        
        setupVideoPlayerWithEpisode(episode: episode)
    }
    
    func updateSaveButtonState(isSaved: Bool) {
        let imageName = isSaved ? "save_Stories_selected" : "save_Stories_unselected"
        saveButton.setImage(UIImage(named: imageName), for: .normal)
    }
    
    private func updateUIForViewType(_ viewType: StoriesPlayingViewTypes) {
        switch viewType {
        case .isOpenStories:
            appTitleHeaderView.isHidden = false
            navigationTitleView.isHidden = true
            userProfieInfoView.isHidden = false
            storieDetailsLabel.isHidden = false
            enjoyFullStoriesView.isHidden = false
            videoSliderView.isHidden = true
            saveButton.isHidden = true
            
            videoSliderViewHeightConstant.constant = 0
            storieDetailsLabelHeightConstraint.constant = 34
            
        case .isOpenAllStoriesEpisods:
            appTitleHeaderView.isHidden = true
            navigationTitleView.isHidden = false
            userProfieInfoView.isHidden = false
            videoSliderView.isHidden = false  // Make sure this is visible
            storieDetailsLabel.isHidden = true
            enjoyFullStoriesView.isHidden = true
            saveButton.isHidden = false
            
            fullStoryViewHeightConstant.constant = 0
            storieDetailsLabelHeightConstraint.constant = 0
            videoSliderViewHeightConstant.constant = 70  // Ensure height is set
            
            // Force layout update
            videoSliderView.setNeedsLayout()
            videoSliderView.layoutIfNeeded()
        }
        
        // Force immediate layout update
        self.contentView.setNeedsLayout()
        self.contentView.layoutIfNeeded()
    }
    
    private func setupVideoPlayerWithDrama(drama: DramaItem) {
        resetVideo()
        
        guard let videoUrlString = drama.epiUrl, !videoUrlString.isEmpty,
              let url = URL(string: videoUrlString) else {
            storiesThumbImageView.isHidden = false
            playButton.isHidden = true
            return
        }
        
        setupPlayer(with: url)
    }
    
    private func setupVideoPlayerWithEpisode(episode: EpisodeItem) {
        resetVideo()
        
        var videoUrlString = ""
        switch selectedQualityIndex {
        case 0:
            videoUrlString = episode.video240p
        case 1:
            videoUrlString = episode.video480p
        case 2:
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
        default:
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
        }
        
        guard !videoUrlString.isEmpty, let url = URL(string: videoUrlString) else {
            storiesThumbImageView.isHidden = false
            playButton.isHidden = true
            return
        }
        
        setupPlayer(with: url)
    }
    
    private func setupPlayer(with url: URL) {
        print("setupPlayer() called with URL: \(url)")
        showLoading()
        
        isPlayerReady = false
        
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = mainView.bounds
        playerLayer?.videoGravity = .resizeAspectFill
        
        if let layer = playerLayer {
            mainView.layer.insertSublayer(layer, below: storiesThumbImageView.layer)
            print("Player layer added to mainView")
        }
        
        updatePlaybackSpeed()
        
        NotificationCenter.default.addObserver(self,
                                             selector: #selector(videoDidEnd),
                                             name: .AVPlayerItemDidPlayToEndTime,
                                             object: playerItem)
        
        playerItem.addObserver(self, forKeyPath: "status", options: [.new, .initial], context: nil)
        playerItem.addObserver(self, forKeyPath: "duration", options: [.new], context: nil)
        
        // Store time observer token so we can remove it later
        timeObserverToken = player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.1, preferredTimescale: CMTimeScale(NSEC_PER_SEC)), queue: .main) { [weak self] time in
            self?.updateSliderPosition()
            self?.updateDurationLabels()
        }
        
        print("Player setup complete - player: \(player != nil ? "exists" : "nil")")
    }
    
    private func updateSliderPosition() {
        guard let player = player,
              let playerItem = player.currentItem else {
            videoSlider.value = 0
            currentVideoProgress = 0.0
            return
        }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else {
            videoSlider.value = 0
            currentVideoProgress = 0.0
            return
        }
        
        let currentTime = CMTimeGetSeconds(player.currentTime())
        let totalDuration = CMTimeGetSeconds(duration)
        
        currentVideoProgress = currentTime / totalDuration
        videoSlider.value = Float(currentVideoProgress)
    }
    
    private func updateDurationLabels() {
        guard let player = player,
              let playerItem = player.currentItem else {
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
            return
        }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else {
            startDurationLabel.text = "0:00"
            endDurationLabel.text = "0:00"
            return
        }
        
        let currentTime = CMTimeGetSeconds(player.currentTime())
        startDurationLabel.text = formatTime(currentTime)
        
        let totalDuration = CMTimeGetSeconds(duration)
        endDurationLabel.text = formatTime(totalDuration)
    }
    
    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite && !seconds.isNaN else {
            return "0:00"
        }
        
        let minutes = Int(seconds) / 60
        let remainingSeconds = Int(seconds) % 60
        return String(format: "%d:%02d", minutes, remainingSeconds)
    }
    
    // MARK: - Loading
    
    private func showLoading() {
        loadingIndicator.startAnimating()
        loadingIndicator.isHidden = false
        playButton.isHidden = true
    }
    
    private func hideLoading() {
        loadingIndicator.stopAnimating()
        loadingIndicator.isHidden = true
    }
    
    // MARK: - SwiftPopup Presentation Methods
    
    private func presentEpisodesBottomSheet() {
        print("=== Presenting Episodes Bottom Sheet with SwiftPopup ===")
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let episodesVC = storyboard.instantiateViewController(withIdentifier: "EpisodesViewBottomPopUp") as? EpisodesViewBottomPopUp else {
            print("Failed to instantiate EpisodesViewBottomPopUp")
            return
        }
        
        // Configure
        let userImageUrl = currentDrama?.imageUrl ?? currentEpisode?.dImage
        let episodesToShow = allEpisodesForDrama.isEmpty ? allEpisodes : allEpisodesForDrama
        
        episodesVC.configure(
            allEpisodes: episodesToShow,
            selectedEpisodeIndex: selectedEpisodeIndex,
            userName: currentDrama?.dramaName ?? currentEpisode?.dName ?? "Unknown",
            userImageUrl: userImageUrl,
            isSubscribed: isSubscribed,
            viewType: storiesPlayingViewType
        )
        
        episodesVC.episodeSelectedHandler = { [weak self] selectedEpisode in
            guard let self = self else { return }
            
            print("Episode selected in popup: \(selectedEpisode.epiName)")
            
            // First, notify the parent handler (for table view scrolling)
            self.episodeSelectedHandler?(selectedEpisode)
            
            // DIRECT FIX: Also handle the episode change within this cell
            // Find the index of the selected episode
            if let index = self.allEpisodes.firstIndex(where: { $0.epiId == selectedEpisode.epiId }) {
                self.selectedEpisodeIndex = index
                self.currentEpisode = selectedEpisode
                
                // Stop current video
                self.pauseVideo()
                
                // Reset video player and setup with new episode
                self.setupVideoPlayerWithEpisode(episode: selectedEpisode)
                
                // Update UI for the new episode
                if self.storiesPlayingViewType == .isOpenAllStoriesEpisods {
                    if !selectedEpisode.thumbnails.isEmpty, let url = URL(string: selectedEpisode.thumbnails) {
                        self.storiesThumbImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "video_placeholder"))
                    }
                    
                    if !selectedEpisode.dImage.isEmpty, let url = URL(string: selectedEpisode.dImage) {
                        self.userProfileImageView.sd_setImage(with: url, placeholderImage: UIImage(named: "user_placeholder"))
                    }
                    
                    let isSaved = LocalStorageManager.shared.isEpisodeSaved(episodeId: selectedEpisode.epiId)
                    self.updateSaveButtonState(isSaved: isSaved)
                }
                
                // Show loading indicator while new video loads
                self.showLoading()
                
                // Hide controls initially
                self.hideControls()
                
                print("Cell updated for selected episode: \(selectedEpisode.epiName)")
            }
        }
        
        episodesVC.closeHandler = { [weak self] in
            guard let self = self else { return }
            if self.isVideoPlaying {
                self.startControlsHideTimer()
            }
        }
        
        // Configure SwiftPopup animations
        let showAnimation = ActionSheetShowAnimation()
        showAnimation.duration = 0.3
        showAnimation.springWithDamping = 0.8
        
        let dismissAnimation = ActionSheetDismissAnimation()
        dismissAnimation.duration = 0.2
        
        episodesVC.showAnimation = showAnimation
        episodesVC.dismissAnimation = dismissAnimation
        
        // Present using SwiftPopup
        episodesPopup = episodesVC
        episodesVC.show()
    }
    
    private func presentSpeedSettingsBottomSheet() {
        print("=== Presenting Speed Settings Bottom Sheet with SwiftPopup ===")
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let speedVC = storyboard.instantiateViewController(withIdentifier: "SpeedSetBottomPopUp") as? SpeedSetBottomPopUp else {
            print("Failed to instantiate SpeedSetBottomPopUp")
            return
        }
        
        // Configure speed view controller
        speedVC.configure(
            selectedSpeedIndex: selectedSpeedIndex,
            selectedQualityIndex: selectedQualityIndex
        )
        
        speedVC.speedChangeHandler = { [weak self] newSpeedIndex in
            guard let self = self else { return }
            print("Speed changed to index: \(newSpeedIndex)")
            self.selectedSpeedIndex = newSpeedIndex
            self.updatePlaybackSpeed()
        }
        
        speedVC.qualityChangeHandler = { [weak self] newQualityIndex in
            guard let self = self else { return }
            print("Quality changed to index: \(newQualityIndex)")
            self.selectedQualityIndex = newQualityIndex
            
            // FIX: Store current playback state
            let wasPlaying = self.isVideoPlaying
            
            // Update video quality
            self.updateVideoQuality()
            
            // FIX: Show loading indicator
            self.showLoading()
            
            // FIX: Reset slider to 0 immediately
            self.videoSlider.value = 0
            self.startDurationLabel.text = "0:00"
            self.currentVideoProgress = 0.0
            
            print("Quality updated, video will restart")
        }
        
        speedVC.closeHandler = { [weak self] in
            guard let self = self else { return }
            if self.isVideoPlaying {
                self.startControlsHideTimer()
            }
        }
        
        // Configure SwiftPopup animations
        let showAnimation = ActionSheetShowAnimation()
        showAnimation.duration = 0.3
        showAnimation.springWithDamping = 0.8
        
        let dismissAnimation = ActionSheetDismissAnimation()
        dismissAnimation.duration = 0.2
        
        speedVC.showAnimation = showAnimation
        speedVC.dismissAnimation = dismissAnimation
        
        // Present using SwiftPopup
        speedPopup = speedVC
        speedVC.show()
    }
    
    private func updatePlaybackSpeed() {
        guard let player = player else { return }
        
        var speed: Float = 1.0
        switch selectedSpeedIndex {
        case 0: speed = 0.75
        case 1: speed = 1.0
        case 2: speed = 1.5
        case 3: speed = 2.0
        default: speed = 1.0
        }
        
        player.rate = speed
    }
    
    private func updateVideoQuality() {
        guard let episode = currentEpisode else { return }
        
        print("updateVideoQuality() called - selectedQualityIndex: \(selectedQualityIndex)")
        
        var videoUrlString = ""
        switch selectedQualityIndex {
        case 0:
            videoUrlString = episode.video240p
            print("Selected quality: 240P")
        case 1:
            videoUrlString = episode.video480p
            print("Selected quality: 480P")
        case 2:
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
            print("Selected quality: 720P")
        default:
            videoUrlString = episode.noSub720p.isEmpty ? episode.video720p : episode.noSub720p
            print("Selected quality: Default (720P)")
        }
        
        if !videoUrlString.isEmpty, let url = URL(string: videoUrlString) {
            print("Switching to new video URL: \(videoUrlString)")
            switchToNewVideo(url: url)
        } else {
            print("Invalid video URL for selected quality")
        }
    }
    
    private func switchToNewVideo(url: URL) {
        print("switchToNewVideo() called with URL: \(url)")
        
        // FIX: Save current playback state before resetting
        let wasPlaying = isVideoPlaying
        
        // Pause video before switching
        pauseVideo()
        
        // Remove existing time observer
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
            timeObserverToken = nil
            print("Removed previous time observer")
        }
        
        resetVideo()
        setupPlayer(with: url)
        
        if wasPlaying {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.playVideo()
            }
        }
    }
    
    // MARK: - Button Actions
    
    @objc private func togglePlayPause() {
        if isVideoPlaying {
            pauseVideo()
        } else {
            playVideo()
        }
        
        resetControlsHideTimer()
    }
    
    @objc private func handleSingleTap(_ gesture: UITapGestureRecognizer) {
        let location = gesture.location(in: self)
        
        let playButtonFrame = playButton.convert(playButton.bounds, to: self)
        if playButtonFrame.contains(location) && !playButton.isHidden {
            return
        }
        
        let shareButtonFrame = shareButton.convert(shareButton.bounds, to: self)
        let saveButtonFrame = saveButton.convert(saveButton.bounds, to: self)
        let backButtonFrame = backButton.convert(backButton.bounds, to: self)
        let moreButtonFrame = moreButton.convert(moreButton.bounds, to: self)
        let allEpisodsButtonFrame = allEpisodsButton.convert(allEpisodsButton.bounds, to: self)
        let enjoyFullStoriesButtonFrame = enjoyFullStoriesButton.convert(enjoyFullStoriesButton.bounds, to: self)
        
        let interactiveElementsFrames = [playButtonFrame, shareButtonFrame, saveButtonFrame, backButtonFrame,
                                       moreButtonFrame, allEpisodsButtonFrame, enjoyFullStoriesButtonFrame]
        
        for frame in interactiveElementsFrames {
            if frame.contains(location) {
                return
            }
        }
        
        if isVideoPlaying {
            toggleControls()
        }
    }
    
    @objc private func handleStoryDetailsTap() {
        isStoryDetailsExpanded = !isStoryDetailsExpanded
        updateStoryDetailsLabel()
        storyDetailsTappedHandler?()
        resetControlsHideTimer()
    }
    
    @objc private func enjoyFullStoriesTapped() {
        enjoyFullStoriesHandler?()
        resetControlsHideTimer()
    }
    
    @objc private func shareButtonTapped() {
        shareHandler?()
        resetControlsHideTimer()
    }
    
    @objc private func saveButtonTapped() {
        saveHandler?()
        resetControlsHideTimer()
    }
    
    @objc private func backButtonTapped() {
        backButtonHandler?()
        resetControlsHideTimer()
    }
    
    @objc private func moreButtonTapped() {
        moreButtonHandler?()
        resetControlsHideTimer()
    }
    
    @objc private func sliderValueChanged(_ sender: UISlider) {
        guard let player = player,
              let playerItem = player.currentItem else { return }
        
        let duration = playerItem.duration
        guard CMTimeGetSeconds(duration).isFinite && !duration.isIndefinite && CMTimeGetSeconds(duration) > 0 else { return }
        
        let totalDuration = CMTimeGetSeconds(duration)
        let targetTime = Double(sender.value) * totalDuration
        let seekTime = CMTime(seconds: targetTime, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        
        player.seek(to: seekTime, toleranceBefore: .zero, toleranceAfter: .zero)
        
        startDurationLabel.text = formatTime(targetTime)
        resetControlsHideTimer()
    }
    
    @objc private func videoDidEnd() {
        print("Video did end - storiesPlayingViewType: \(storiesPlayingViewType)")
        
        // Reset player to start
        player?.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero)
        
        // Update UI state
        isVideoPlaying = false
        playButton.setImage(UIImage(named: "play"), for: .normal)
        videoSlider.value = 0
        startDurationLabel.text = "0:00"
        
        // Show controls permanently when video ends
        showControlsPermanently()
        
        // Reset controls hide timer since video is paused
        controlsHideTimer?.invalidate()
        controlsHideTimer = nil
        
        print("Video ended - ready to replay")
    }
    
    private func setupStoryDetailsLabel() {
        updateStoryDetailsLabel()
    }
    
    private func updateStoryDetailsLabel() {
        guard let text = storieDetailsLabel.text else {
            storieDetailsLabelHeightConstraint.constant = 0
            return
        }
        
        if isStoryDetailsExpanded {
            storieDetailsLabel.numberOfLines = 0
            storieDetailsLabelHeightConstraint.constant = calculateLabelHeight(for: text, width: storieDetailsLabel.frame.width)
        } else {
            storieDetailsLabel.numberOfLines = 2
            storieDetailsLabelHeightConstraint.constant = calculateLabelHeight(for: text, width: storieDetailsLabel.frame.width, maxLines: 2)
        }
    }
    
    private func calculateLabelHeight(for text: String, width: CGFloat, maxLines: Int = 0) -> CGFloat {
        let label = UILabel()
        label.numberOfLines = maxLines
        label.font = storieDetailsLabel.font
        label.text = text
        
        let maxSize = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let requiredSize = label.sizeThatFits(maxSize)
        return requiredSize.height
    }
    
    // MARK: - Setup Methods
    
    private func setupControls() {
        // Controls setup
    }
    
    private func setupSlider() {
        videoSlider.minimumTrackTintColor = .white
        videoSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.3)
        videoSlider.minimumValue = 0
        videoSlider.maximumValue = 1
        
        let thumbSize: CGFloat = 20
        let thumbImage = createThumbImage(size: thumbSize, color: .white)
        videoSlider.setThumbImage(thumbImage, for: .normal)
        videoSlider.setThumbImage(thumbImage, for: .highlighted)
        
        videoSlider.addTarget(self, action: #selector(sliderValueChanged(_:)), for: .valueChanged)
    }
    
    private func createThumbImage(size: CGFloat, color: UIColor) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: size, height: size))
        return renderer.image { context in
            color.setFill()
            context.cgContext.fillEllipse(in: CGRect(x: 0, y: 0, width: size, height: size))
            UIColor.black.withAlphaComponent(0.3).setFill()
            let innerSize = size - 6
            context.cgContext.fillEllipse(in: CGRect(x: 3, y: 3, width: innerSize, height: innerSize))
        }
    }
    
    private func setupButtonActions() {
        enjoyFullStoriesButton.addTarget(self, action: #selector(enjoyFullStoriesTapped), for: .touchUpInside)
        shareButton.addTarget(self, action: #selector(shareButtonTapped), for: .touchUpInside)
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        moreButton.addTarget(self, action: #selector(moreButtonTapped), for: .touchUpInside)
        playButton.addTarget(self, action: #selector(playButtonAction(_:)), for: .touchUpInside)
        allEpisodsButton.addTarget(self, action: #selector(allEpisodsViewButtonAction), for: .touchUpInside)
        
        playButton.isUserInteractionEnabled = true
    }
    
    private func setupGestureRecognizers() {
        let singleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleSingleTap(_:)))
        singleTapGesture.numberOfTapsRequired = 1
        singleTapGesture.delegate = self
        mainView.addGestureRecognizer(singleTapGesture)
        mainView.isUserInteractionEnabled = true
        
        let detailsTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleStoryDetailsTap))
        storieDetailsLabel.addGestureRecognizer(detailsTapGesture)
    }
    
    // MARK: - KVO
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        print("observeValue() - keyPath: \(keyPath ?? "nil")")
        guard let playerItem = object as? AVPlayerItem else { return }
        
        if keyPath == "status" {
            print("Player status changed")
            switch playerItem.status {
            case .readyToPlay:
                print("Video is ready to play")
                isPlayerReady = true
                hideLoading()
                
                DispatchQueue.main.async {
                    // FIX: Reset slider to 0 when new video is ready
                    self.videoSlider.value = 0
                    self.startDurationLabel.text = "0:00"
                    self.currentVideoProgress = 0.0
                    
                    self.showControls()
                    if self.isVideoPlaying {
                        self.playButton.setImage(UIImage(named: "pause"), for: .normal)
                    } else {
                        self.playButton.setImage(UIImage(named: "play"), for: .normal)
                    }
                    
                    if self.shouldAutoPlay && !self.isVideoPlaying {
                        print("Auto-playing video after ready")
                        self.playVideo()
                    }
                }
                
                updateDurationLabels()
            case .failed:
                print("Video failed to load: \(playerItem.error?.localizedDescription ?? "Unknown error")")
                isPlayerReady = false
                hideLoading()
                storiesThumbImageView.isHidden = false
                hideControls()
            case .unknown:
                print("Video status unknown")
                isPlayerReady = false
            @unknown default:
                break
            }
        } else if keyPath == "duration" {
            updateDurationLabels()
        }
    }
    
    // MARK: - Helper Methods
    
    private func showToastMessage(message: String) {
        print("Toast: \(message)")
        
        if let viewController = self.window?.rootViewController {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            viewController.present(alert, animated: true) {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    alert.dismiss(animated: true)
                }
            }
        }
    }
    
    func getCurrentVideoProgress() -> Double {
        return currentVideoProgress
    }
    
    deinit {
        resetVideo()
        controlsHideTimer?.invalidate()
        controlsHideTimer = nil
    }
}

// MARK: - Button Actions Extension
extension StoriesPlayingCell {
    
    @IBAction func allEpisodsViewButtonAction(_ sender: UIButton) {
        presentEpisodesBottomSheet()
        resetControlsHideTimer()
    }
    
    @IBAction func shareButtonAction(_ sender: UIButton) {
        shareHandler?()
        resetControlsHideTimer()
    }
    
    @IBAction func saveButtonAction(_ sender: UIButton) {
        guard let episode = currentEpisode, storiesPlayingViewType == .isOpenAllStoriesEpisods else { return }
        
        let isCurrentlySaved = LocalStorageManager.shared.isEpisodeSaved(episodeId: episode.epiId)
        
        if isCurrentlySaved {
            LocalStorageManager.shared.removeSavedEpisode(episodeId: episode.epiId)
            updateSaveButtonState(isSaved: false)
            showToastMessage(message: "Removed from My List")
        } else {
            let success = LocalStorageManager.shared.saveEpisode(episode)
            updateSaveButtonState(isSaved: success)
            if success {
                showToastMessage(message: "Saved to My List")
            } else {
                showToastMessage(message: "Already in My List")
            }
        }
        
        saveHandler?()
        resetControlsHideTimer()
    }
    
    @IBAction func moreButtonAction(_ sender: UIButton) {
        presentSpeedSettingsBottomSheet()
        resetControlsHideTimer()
    }
    
    @IBAction func playButtonAction(_ sender: UIButton) {
        print("Play button tapped - current state: \(isVideoPlaying ? "playing" : "paused")")
        
        if isVideoPlaying {
            pauseVideo()
        } else {
            // Check if video is at the end
            if let player = player,
               let playerItem = player.currentItem {
                let duration = playerItem.duration
                let currentTime = player.currentTime()
                
                // If video is at or near the end, restart from beginning
                if CMTimeCompare(currentTime, duration) >= 0 ||
                   (CMTimeGetSeconds(duration) - CMTimeGetSeconds(currentTime)) < 0.5 {
                    player.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero)
                    print("Video restarted from beginning")
                }
            }
            
            playVideo()
        }
    }
}

// MARK: - UIGestureRecognizerDelegate
extension StoriesPlayingCell {
    override func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        let location = touch.location(in: self)
        
        let playButtonFrame = playButton.convert(playButton.bounds, to: self)
        let shareButtonFrame = shareButton.convert(shareButton.bounds, to: self)
        let saveButtonFrame = saveButton.convert(saveButton.bounds, to: self)
        let backButtonFrame = backButton.convert(backButton.bounds, to: self)
        let moreButtonFrame = moreButton.convert(moreButton.bounds, to: self)
        let allEpisodsButtonFrame = allEpisodsButton.convert(allEpisodsButton.bounds, to: self)
        let enjoyFullStoriesButtonFrame = enjoyFullStoriesButton.convert(enjoyFullStoriesButton.bounds, to: self)
        
        let interactiveElementsFrames = [playButtonFrame, shareButtonFrame, saveButtonFrame, backButtonFrame,
                                       moreButtonFrame, allEpisodsButtonFrame, enjoyFullStoriesButtonFrame]
        
        for frame in interactiveElementsFrames {
            if frame.contains(location) {
                return false
            }
        }
        
        return true
    }
}
