//
//  StoriesVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 04/12/25.
//

import UIKit
import SVProgressHUD
import Lottie

enum StoriesPlayingViewTypes {
    case isOpenStories
    case isOpenAllStoriesEpisods
}
class StoriesVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var suggetionView: UIView!
    @IBOutlet weak var lottieAnimationView: UIView!
    @IBOutlet weak var swipeLabel: UILabel!
    
    var storiesPlayingViewType: StoriesPlayingViewTypes = .isOpenStories
    var allDramaStories: [DramaItem] = []
    
    // Add episodes dictionary to store episodes for each drama
    private var episodesForDramas: [String: [EpisodeItem]] = [:]
    
    var isFirstTimeOpenStories: Bool {
        get { UserDefaults.standard.bool(forKey: "isFirstTimeOpenStories") == false }
        set { UserDefaults.standard.set(!newValue, forKey: "isFirstTimeOpenStories") }
    }

    // Properties for pagination
    private var currentPage = 1
    private var isLoading = false
    private var hasMoreData = true
    private var currentPlayingIndex: Int = -1
    private var initialLoadComplete = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()

        // Hide suggestion view by default
        suggetionView.isHidden = true

        // Handle first-time animation
        handleFirstTimeSuggestion()

        // Show loading & fetch data
        showInitialLoading()
        fetchAllStories(page: 1)
        
        // Add observer for when table view finishes loading
        tableView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateNavigationBar()
    }
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "contentSize" {
            // Auto-play first video when table view content is loaded
            if !allDramaStories.isEmpty && currentPlayingIndex == -1 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self.playVideoForVisibleCell()
                }
            }
        }
    }

//    deinit {
//        tableView.removeObserver(self, forKeyPath: "contentSize")
//    }
    private func updateNavigationBar() {
        // Always hide navigation bar for stories
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    private func showInitialLoading() {
        SVProgressHUD.show()
    }
    
    private func hideInitialLoading() {
        SVProgressHUD.dismiss()
    }
    func setUpUI() {
        settable()
        self.swipeLabel.text = "Swipe to see more".localized(LocalizationService.shared.language)
    }
    func settable() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(["StoriesPlayingCell"])
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = .black
        self.tableView.isPagingEnabled = true
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.contentInsetAdjustmentBehavior = .never
        
        // Initially hide table view until data loads
        tableView.isHidden = true
    }
    func handleFirstTimeSuggestion() {
        guard isFirstTimeOpenStories else { return }

        // Lottie animation
        let animationView = LottieAnimationView(name: "Swipe Up")
        animationView.frame = lottieAnimationView.bounds
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop
        lottieAnimationView.addSubview(animationView)

        suggetionView.isHidden = false
        animationView.play { [weak self] _ in
            self?.isFirstTimeOpenStories = false
        }

        // Tap Gesture (simple touch)
        let tap = UITapGestureRecognizer(target: self, action: #selector(hideSuggestion))
        suggetionView.addGestureRecognizer(tap)

        // Pan Gesture (swipe, drag, scroll)
        let pan = UIPanGestureRecognizer(target: self, action: #selector(hideSuggestionOnPan(_:)))
        suggetionView.addGestureRecognizer(pan)
    }

    private func playVideoForVisibleCell() {
        guard let indexPath = getCenterCellIndexPath() else { return }
        
        print("playVideoForVisibleCell() - indexPath: \(indexPath.row), currentPlayingIndex: \(currentPlayingIndex)")
        
        // If we're already playing this cell, do nothing
        if currentPlayingIndex == indexPath.row {
            print("Already playing this cell, returning")
            return
        }
        
        // Pause previously playing video
        if currentPlayingIndex >= 0 {
            print("Pausing previous cell at index: \(currentPlayingIndex)")
            if let previousCell = tableView.cellForRow(at: IndexPath(row: currentPlayingIndex, section: 0)) as? StoriesPlayingCell {
                previousCell.pauseVideo()
            }
        }
        
        // Play new video
        if let currentCell = tableView.cellForRow(at: indexPath) as? StoriesPlayingCell {
            print("Playing new cell at index: \(indexPath.row)")
            currentCell.playVideoIfReady() // Use new method instead of playVideo()
            currentPlayingIndex = indexPath.row
            
            // Load more data when near the end
            if indexPath.row >= allDramaStories.count - 3 && !isLoading {
                loadMoreData()
            }
        } else {
            print("Failed to get cell at indexPath: \(indexPath)")
        }
    }
    
    private func getCenterCellIndexPath() -> IndexPath? {
        let center = view.convert(tableView.center, to: tableView)
        return tableView.indexPathForRow(at: center)
    }
    
    private func loadMoreData() {
        guard !isLoading && hasMoreData else { return }
        fetchAllStories(page: currentPage + 1, isLoadMore: true)
    }
    
    private func pauseAllVideos() {
        for cell in tableView.visibleCells {
            if let storiesCell = cell as? StoriesPlayingCell {
                storiesCell.pauseVideo()
            }
        }
        currentPlayingIndex = -1
    }
    
    func navigateToViewAllEpisodes(for dramaId: String, dramaName: String?, allEpisodes: [EpisodeItem] = []) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let viewAllEpisodesVC = storyboard.instantiateViewController(withIdentifier: "ViewAllEpisodsStoriesVC") as? ViewAllEpisodsStoriesVC {
            viewAllEpisodesVC.dramaId = dramaId
            viewAllEpisodesVC.dramaName = dramaName
            viewAllEpisodesVC.storiesPlayingViewType = .isOpenAllStoriesEpisods
            viewAllEpisodesVC.allEpisodes = allEpisodes
            viewAllEpisodesVC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(viewAllEpisodesVC, animated: true)
        }
    }
    // MARK: - Share Method
    private func shareDrama(_ drama: DramaItem) {
        guard let dramaName = drama.dramaName else { return }

        let shareText = "Check out \(dramaName) on our app!"
        var shareItems: [Any] = [shareText]

        // ✅ If image URL exists, load asynchronously
        if let imageUrlString = drama.imageUrl,
           let imageUrl = URL(string: imageUrlString) {

            URLSession.shared.dataTask(with: imageUrl) { [weak self] data, response, error in
                
                if let data = data,
                   let image = UIImage(data: data) {
                    shareItems.append(image)
                }

                // ✅ Present on MAIN thread
                DispatchQueue.main.async {
                    self?.presentShareSheet(items: shareItems)
                }

            }.resume()

        } else {
            // ✅ No image → just share text
            presentShareSheet(items: shareItems)
        }
    }
    private func presentShareSheet(items: [Any]) {
        let activityViewController = UIActivityViewController(
            activityItems: items,
            applicationActivities: nil
        )

        if let popoverController = activityViewController.popoverPresentationController {
            popoverController.sourceView = self.view
            popoverController.sourceRect = CGRect(
                x: self.view.bounds.midX,
                y: self.view.bounds.midY,
                width: 0,
                height: 0
            )
            popoverController.permittedArrowDirections = []
        }

        present(activityViewController, animated: true)
    }
    @objc func hideSuggestion() {
        UIView.animate(withDuration: 0.3) {
            self.suggetionView.alpha = 0
        } completion: { _ in
            self.suggetionView.isHidden = true
            self.suggetionView.alpha = 1
        }
    }
    @objc func hideSuggestionOnPan(_ gesture: UIPanGestureRecognizer) {
        if gesture.state == .began || gesture.state == .changed {
            hideSuggestion()
        }
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension StoriesVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allDramaStories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StoriesPlayingCell",
                                                 for: indexPath) as? StoriesPlayingCell ?? StoriesPlayingCell()
        cell.selectionStyle = .none
        
        if indexPath.row < allDramaStories.count {
            let drama = allDramaStories[indexPath.row]
            
            // Get episodes for this drama
            let episodesForDrama = episodesForDramas[drama.id ?? ""] ?? []
            
            // Configure cell with drama data for isOpenStories view
            cell.configureWithDrama(drama: drama,
                                   viewType: .isOpenStories,
                                   allEpisodes: episodesForDrama)
            
            // Handle enjoy full stories button tap
            cell.enjoyFullStoriesHandler = { [weak self] in
                guard let self = self, let dramaId = drama.id else { return }
                let episodes = self.episodesForDramas[dramaId] ?? []
                self.navigateToViewAllEpisodes(for: dramaId,
                                               dramaName: drama.dramaName,
                                               allEpisodes: episodes)
            }
            
            // Handle story details expansion
            cell.storyDetailsTappedHandler = { [weak self] in
                tableView.beginUpdates()
                tableView.endUpdates()
            }
            
            // Handle share button
            cell.shareHandler = { [weak self] in
                self?.shareDrama(drama)
            }
            
            // Handle episode selection from popup
            cell.episodeSelectedHandler = { [weak self] selectedEpisode in
                guard let self = self, let dramaId = drama.id else { return }
                let allEpisodes = self.episodesForDramas[dramaId] ?? []
                self.navigateToViewAllEpisodes(for: dramaId,
                                               dramaName: drama.dramaName,
                                               allEpisodes: allEpisodes)
                // Note: The selected episode can be used to start playing from that specific episode
                // in ViewAllEpisodsStoriesVC if needed
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.height
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let storiesCell = cell as? StoriesPlayingCell {
            storiesCell.pauseVideo()
            if currentPlayingIndex == indexPath.row {
                currentPlayingIndex = -1
            }
        }
    }
}
// MARK: - Scroll autoplay
extension StoriesVC: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        playVideoForVisibleCell()
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            playVideoForVisibleCell()
        }
    }
}
// MARK: - Api's calling
extension StoriesVC {
    func fetchAllStories(page: Int, isLoadMore: Bool = false) {
        guard !isLoading, (isLoadMore ? hasMoreData : true) else { return }
        
        isLoading = true
        if !isLoadMore {
            SVProgressHUD.show()
        }
        
        NetworkManager.shared.fetchDramas(from: self, page: page) { [weak self] result in
            guard let self = self else { return }
            
            self.isLoading = false
            if !isLoadMore {
                SVProgressHUD.dismiss()
            }
            
            switch result {
            case .success(let response):
                // Process sections based on heading
                var newDramas: [DramaItem] = []
                for section in response.data.data {
                    // Filter items that have drama_name and image_url
                    let validItems = section.list.filter { item in
                        let hasName = item.dramaName != nil && !item.dramaName!.isEmpty
                        let hasImage = item.imageUrl != nil && !item.imageUrl!.isEmpty
                        return hasName && hasImage
                    }
                    newDramas.append(contentsOf: validItems)
                }
                
                if isLoadMore {
                    self.allDramaStories.append(contentsOf: newDramas)
                } else {
                    self.allDramaStories = newDramas
                    
                    // Hide initial loading and show table view
                    DispatchQueue.main.async {
                        self.hideInitialLoading()
                        self.tableView.isHidden = false
                        self.initialLoadComplete = true
                    }
                }
                
                // Update pagination state
                self.hasMoreData = !newDramas.isEmpty
                if self.hasMoreData {
                    self.currentPage = page
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    
                    // Auto-play first video if initial load
                    if !isLoadMore && !self.allDramaStories.isEmpty {
                        // Small delay to ensure cells are properly configured
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            print("Initial load complete, attempting to play first video")
                            self.playVideoForVisibleCell()
                        }
                    }
                    
                    // Fetch episodes for each drama
                    self.fetchEpisodesForAllDramas()
                }
                
            case .failure(let error):
                print("Error fetching dramas: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.hideInitialLoading()
                    self.tableView.isHidden = false
                    
                    if self.allDramaStories.isEmpty {
                        self.showEmptyState()
                    }
                }
            }
        }
    }
    
    private func fetchEpisodesForAllDramas() {
        for drama in allDramaStories {
            guard let dramaId = drama.id else { continue }
            
            // Fetch episodes for this drama
            NetworkManager.shared.fetchEpisodes(from: self, dramaId: dramaId, page: 1) { [weak self] result in
                guard let self = self else { return }
                
                switch result {
                case .success(let episodes):
                    // Store episodes for this drama
                    self.episodesForDramas[dramaId] = episodes
                    
                    // Reload the specific cell if it's visible
                    DispatchQueue.main.async {
                        if let index = self.allDramaStories.firstIndex(where: { $0.id == dramaId }) {
                            let indexPath = IndexPath(row: index, section: 0)
                            if self.tableView.indexPathsForVisibleRows?.contains(indexPath) == true {
                                self.tableView.reloadRows(at: [indexPath], with: .none)
                            }
                        }
                    }
                    
                case .failure(let error):
                    print("Error fetching episodes for drama \(dramaId): \(error.localizedDescription)")
                }
            }
        }
    }
    
    private func showEmptyState() {
        let emptyLabel = UILabel(frame: CGRect(x: 0, y: 0, width: tableView.bounds.width, height: tableView.bounds.height))
        emptyLabel.text = "No stories available"
        emptyLabel.textColor = .white
        emptyLabel.textAlignment = .center
        emptyLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        
        tableView.backgroundView = emptyLabel
    }
}
