//
//  ViewAllEpisodsStoriesVC.swift
//  DramaBox
//
//  Created by DREAMWORLD on 08/12/25.
//

import UIKit
import SVProgressHUD

class ViewAllEpisodsStoriesVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var dramaId: String?
    var dramaName: String?
    var storiesPlayingViewType: StoriesPlayingViewTypes = .isOpenAllStoriesEpisods
    var isOpenFromSuggestionVC: Bool = false
    var isOpenFromMyList: Bool = false
    
    private var episodes: [EpisodeItem] = []
    
    // Add this public property to receive episodes from StoriesVC
    var allEpisodes: [EpisodeItem] = [] // Add this line
    
    // Properties for pagination
    private var currentPage = 1
    private var isLoading = false
    private var hasMoreData = true
    private var currentPlayingIndex: Int = -1
    private var initialLoadComplete = false
    
    // MARK: - Watch History Tracking
    private var currentWatchedEpisodeId: String?
    private var watchStartTime: Date?
    private var currentWatchProgress: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        
        // Start watching the first episode if passed from StoriesVC
        if !allEpisodes.isEmpty {
            self.episodes = allEpisodes
            hideInitialLoading()
            tableView.isHidden = false
            tableView.reloadData()
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.playVideoForVisibleCell()
                // Start tracking watch time for first episode
                if let firstEpisode = self.episodes.first {
                    self.startWatchingEpisode(firstEpisode)
                }
            }
        } else {
            fetchEpisodes()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
        
        // Auto-play first video when view appears
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.playVideoForVisibleCell()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        pauseAllVideos()
        stopWatchingEpisode() // Save watch history when leaving
    }
    
    private func showInitialLoading() {
        SVProgressHUD.show()
    }
    
    private func hideInitialLoading() {
        SVProgressHUD.dismiss()
    }
    
    func setUpUI() {
        settable()
    }
    
    func settable() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(["StoriesPlayingCell"])
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = .black
        self.tableView.isPagingEnabled = true
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.contentInsetAdjustmentBehavior = .never
        
        // Initially hide table view until data loads
        tableView.isHidden = true
    }
    
    private func pauseAllVideos() {
        for cell in tableView.visibleCells {
            if let storiesCell = cell as? StoriesPlayingCell {
                storiesCell.pauseVideo()
            }
        }
        currentPlayingIndex = -1
    }
    
    private func playVideoForVisibleCell() {
        guard let indexPath = getCenterCellIndexPath() else { return }
        
        print("Playing video for cell at index: \(indexPath.row)")
        
        // If we're already playing this cell, do nothing
        if currentPlayingIndex == indexPath.row {
            return
        }
        
        // Pause previously playing video
        if currentPlayingIndex >= 0 {
            if let previousCell = tableView.cellForRow(at: IndexPath(row: currentPlayingIndex, section: 0)) as? StoriesPlayingCell {
                previousCell.pauseVideo()
            }
        }
        
        // Play new video
        if let currentCell = tableView.cellForRow(at: indexPath) as? StoriesPlayingCell {
            currentCell.playVideoIfReady()
            currentPlayingIndex = indexPath.row
            
            // Start tracking watch time for this episode
            let episode = episodes[indexPath.row]
            stopWatchingEpisode()
            startWatchingEpisode(episode)
        }
    }
    
    private func getCenterCellIndexPath() -> IndexPath? {
        let center = view.convert(tableView.center, to: tableView)
        return tableView.indexPathForRow(at: center)
    }
    
    // MARK: - Watch History Methods
    private func startWatchingEpisode(_ episode: EpisodeItem) {
        currentWatchedEpisodeId = episode.epiId
        watchStartTime = Date()
        currentWatchProgress = 0.0
    }
    private func stopWatchingEpisode() {
        guard let episodeId = currentWatchedEpisodeId,
              let startTime = watchStartTime,
              let episode = episodes.first(where: { $0.epiId == episodeId }) else {
            return
        }
        
        let watchDuration = Date().timeIntervalSince(startTime)
        
        // Save to watch history
        LocalStorageManager.shared.saveWatchHistory(
            episode: episode,
            duration: watchDuration,
            progress: currentWatchProgress
        )
        
        // Reset tracking
        currentWatchedEpisodeId = nil
        watchStartTime = nil
        currentWatchProgress = 0.0
    }
    private func updateWatchProgress(for episode: EpisodeItem, progress: Double) {
        guard episode.epiId == currentWatchedEpisodeId else { return }
        currentWatchProgress = max(currentWatchProgress, progress)
    }
    
    // MARK: - Episode Save Handling
    private func saveEpisode(_ episode: EpisodeItem) {
        let success = LocalStorageManager.shared.saveEpisode(episode)
        
        // Show feedback to user
        if success {
            showToast(message: "Episode saved to My List")
        } else {
            showToast(message: "Episode already in My List")
        }
        
        // Update save button state in all visible cells
        updateSaveButtonStates()
    }
    private func updateSaveButtonStates() {
        for cell in tableView.visibleCells {
            if let storiesCell = cell as? StoriesPlayingCell,
               let episode = storiesCell.currentEpisode {
                let isSaved = LocalStorageManager.shared.isEpisodeSaved(episodeId: episode.epiId)
                storiesCell.updateSaveButtonState(isSaved: isSaved)
            }
        }
    }
    
    private func showToast(message: String) {
        let toast = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        present(toast, animated: true) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                toast.dismiss(animated: true)
            }
        }
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension ViewAllEpisodsStoriesVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return episodes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StoriesPlayingCell",
                                                 for: indexPath) as? StoriesPlayingCell ?? StoriesPlayingCell()
        cell.selectionStyle = .none
        
        if indexPath.row < episodes.count {
            let episode = episodes[indexPath.row]
            
            // Configure cell with episode data
            cell.configureWithEpisode(episode: episode,
                                      viewType: .isOpenAllStoriesEpisods,
                                      dramaName: self.dramaName,
                                      allEpisodes: self.episodes,
                                      currentIndex: indexPath.row)
            // Force layout update
            cell.setNeedsLayout()
            cell.layoutIfNeeded()
            
            if isOpenFromSuggestionVC {
                cell.moreButton.isHidden = true
                cell.allEpisodsButton.isHidden = true
            }
            
            // Handle share button
            cell.shareHandler = { [weak self] in
                self?.shareEpisode(episode)
            }
            
            // Handle save button
            cell.saveHandler = { [weak self] in
                self?.saveEpisode(episode)
            }
            
            // Handle back button
            cell.backButtonHandler = { [weak self] in
                guard let self = self else { return }
                
                // Highest priority: coming from MyList
                if self.isOpenFromMyList == true {
                    self.navigationController?.popViewController(animated: true)
                    return
                }
                
                // Coming from SuggestionVC?
                if self.isOpenFromSuggestionVC == false {
                    self.presentSuggestStoriesVC()
                } else {
                    self.dismiss(animated: true)
                }
            }
            
            // Handle episode selection from popup - MODIFIED
            cell.episodeSelectedHandler = { [weak self] selectedEpisode in
                guard let self = self else { return }
                
                if let index = self.episodes.firstIndex(where: { $0.epiId == selectedEpisode.epiId }) {
                    let indexPath = IndexPath(row: index, section: 0)
                    
                    // FIX: Scroll to the selected episode
                    tableView.scrollToRow(at: indexPath, at: .middle, animated: false)
                    
                    // IMPORTANT: After scrolling, update the cell at that index to play
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        // Pause all other videos
                        self.pauseAllVideos()
                        
                        // Get the newly visible cell
                        if let visibleCell = tableView.cellForRow(at: indexPath) as? StoriesPlayingCell {
                            // Configure with the selected episode again to ensure it's updated
                            visibleCell.configureWithEpisode(episode: selectedEpisode,
                                                             viewType: .isOpenAllStoriesEpisods,
                                                             dramaName: self.dramaName,
                                                             allEpisodes: self.episodes,
                                                             currentIndex: index)
                            
                            // Play the video after a short delay
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                visibleCell.playVideoIfReady()
                                self.currentPlayingIndex = index
                            }
                        }
                        
                        // Start tracking watch time for selected episode
                        self.stopWatchingEpisode()
                        self.startWatchingEpisode(selectedEpisode)
                    }
                }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.height
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let storiesCell = cell as? StoriesPlayingCell {
            storiesCell.pauseVideo()
            if currentPlayingIndex == indexPath.row {
                currentPlayingIndex = -1
            }
        }
    }
    private func shareEpisode(_ episode: EpisodeItem) {
        let shareText = "Watch \(episode.epiName) from \(episode.dName)"
        let activityViewController = UIActivityViewController(activityItems: [shareText], applicationActivities: nil)
        present(activityViewController, animated: true)
    }
}

// MARK: - Scroll autoplay
extension ViewAllEpisodsStoriesVC: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        playVideoForVisibleCell()
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            playVideoForVisibleCell()
        }
    }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        // This is called after programmatic scrolling (like when selecting from popup)
        playVideoForVisibleCell()
    }
}

// MARK: - Api's calling
extension ViewAllEpisodsStoriesVC {
    func fetchEpisodes(isLoadMore: Bool = false) {
        guard let dramaId = dramaId, !dramaId.isEmpty else {
            showAlert(message: "Invalid drama ID")
            return
        }
        
        guard !isLoading, (isLoadMore ? hasMoreData : true) else { return }
        
        isLoading = true
        
        NetworkManager.shared.fetchEpisodes(from: self, dramaId: dramaId, page: currentPage) { [weak self] result in
            guard let self = self else { return }
            
            self.isLoading = false
            
            switch result {
            case .success(let newEpisodes):
                if isLoadMore {
                    self.episodes.append(contentsOf: newEpisodes)
                } else {
                    self.episodes = newEpisodes
                    
                    // Hide initial loading and show table view
                    DispatchQueue.main.async {
                        self.hideInitialLoading()
                        self.tableView.isHidden = false
                        self.initialLoadComplete = true
                    }
                }
                
                // Update pagination state
                self.hasMoreData = !newEpisodes.isEmpty
                if self.hasMoreData {
                    self.currentPage += 1
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    
                    // Auto-play first video if initial load
                    if !isLoadMore && !self.episodes.isEmpty && self.initialLoadComplete {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            self.playVideoForVisibleCell()
                        }
                    }
                }
                
            case .failure(let error):
                print("Error fetching episodes: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.hideInitialLoading()
                    self.tableView.isHidden = false
                    self.showAlert(message: "Failed to load episodes. Please try again.")
                }
            }
        }
    }
    
    func loadMoreEpisodes() {
        guard !isLoading && hasMoreData else { return }
        fetchEpisodes(isLoadMore: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error",
                                      message: message,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    private func presentSuggestStoriesVC() {
        let suggestVC = SuggestStoriesVC(nibName: "SuggestStoriesVC", bundle: nil)
        suggestVC.modalPresentationStyle = .fullScreen
        suggestVC.modalTransitionStyle = .crossDissolve
        // Set close handler
        suggestVC.closeHandler = { [weak self] in
            // Dismiss the xib and pop to StoriesVC
            self?.dismiss(animated: true) {
                self?.navigationController?.popViewController(animated: true)
            }
        }
        
        self.present(suggestVC, animated: true)
    }

    // Helper method to extract categories from episodes
    private func getAllCategoriesFromEpisodes() -> [String] {
        var categories: Set<String> = []
        
        for episode in episodes {
            // Assuming category information is in episode.dName or other property
            // Adjust based on your actual data structure
            if let firstSpaceIndex = episode.dName.firstIndex(of: " ") {
                let category = String(episode.dName[..<firstSpaceIndex])
                categories.insert(category)
            }
        }
        
        return Array(categories).shuffled()
    }
}
